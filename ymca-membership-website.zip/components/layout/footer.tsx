import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function Footer() {
  return (
    <footer className="bg-card border-t border-border mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* About Section */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-sm">Y</span>
              </div>
              <span className="text-xl font-bold text-foreground">YMCA Community</span>
            </div>
            <p className="text-muted-foreground mb-4 max-w-md">
              Building stronger communities through meaningful connections, professional development, and collaborative
              learning opportunities for all YMCA members.
            </p>
            <div className="flex space-x-4">
              <Button variant="ghost" size="sm">
                <span className="h-4 w-4 flex items-center justify-center">📘</span>
              </Button>
              <Button variant="ghost" size="sm">
                <span className="h-4 w-4 flex items-center justify-center">🐦</span>
              </Button>
              <Button variant="ghost" size="sm">
                <span className="h-4 w-4 flex items-center justify-center">📷</span>
              </Button>
              <Button variant="ghost" size="sm">
                <span className="h-4 w-4 flex items-center justify-center">💼</span>
              </Button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-sm font-semibold text-foreground uppercase tracking-wider mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="text-muted-foreground hover:text-foreground transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/directory" className="text-muted-foreground hover:text-foreground transition-colors">
                  Member Directory
                </Link>
              </li>
              <li>
                <Link href="/events" className="text-muted-foreground hover:text-foreground transition-colors">
                  Upcoming Events
                </Link>
              </li>
              <li>
                <Link href="/forums" className="text-muted-foreground hover:text-foreground transition-colors">
                  Discussion Forums
                </Link>
              </li>
              <li>
                <Link href="/help" className="text-muted-foreground hover:text-foreground transition-colors">
                  Help & Support
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-sm font-semibold text-foreground uppercase tracking-wider mb-4">Contact</h3>
            <ul className="space-y-3">
              <li className="flex items-center text-muted-foreground">
                <span className="h-4 w-4 mr-2 flex items-center justify-center">✉️</span>
                <span className="text-sm">community@ymca.org</span>
              </li>
              <li className="flex items-center text-muted-foreground">
                <span className="h-4 w-4 mr-2 flex items-center justify-center">📞</span>
                <span className="text-sm">1-800-YMCA-USA</span>
              </li>
              <li className="flex items-start text-muted-foreground">
                <span className="h-4 w-4 mr-2 mt-0.5 flex items-center justify-center">📍</span>
                <span className="text-sm">
                  101 North Wacker Drive
                  <br />
                  Chicago, IL 60606
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Newsletter Signup */}
        <div className="mt-8 pt-8 border-t border-border">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h3 className="text-lg font-semibold text-foreground mb-2">Stay Connected</h3>
              <p className="text-muted-foreground">Get the latest updates and community news.</p>
            </div>
            <div className="flex w-full md:w-auto">
              <Input placeholder="Enter your email" className="rounded-r-none md:w-64" />
              <Button className="rounded-l-none">Subscribe</Button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-8 pt-8 border-t border-border flex flex-col md:flex-row justify-between items-center">
          <p className="text-muted-foreground text-sm">© 2024 YMCA Community Platform. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <Link href="/privacy" className="text-muted-foreground hover:text-foreground text-sm transition-colors">
              Privacy Policy
            </Link>
            <Link href="/terms" className="text-muted-foreground hover:text-foreground text-sm transition-colors">
              Terms of Service
            </Link>
            <Link href="/cookies" className="text-muted-foreground hover:text-foreground text-sm transition-colors">
              Cookie Policy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
