"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"

const navigation = [
  { name: "Dashboard", href: "/dashboard", icon: "🏠" },
  { name: "My Profile", href: "/profile", icon: "👤" },
  { name: "Member Directory", href: "/directory", icon: "👥" },
  { name: "Discussion Forums", href: "/forums", icon: "💬", badge: "5" },
  { name: "Events & Webinars", href: "/events", icon: "📅", badge: "2" },
  { name: "Content Library", href: "/library", icon: "📚" },
  { name: "Messages", href: "/messages", icon: "✉️", badge: "3" },
  { name: "Notifications", href: "/notifications", icon: "🔔" },
]

const quickLinks = [
  { name: "Popular Topics", href: "/forums/popular", icon: "#️⃣" },
  { name: "Saved Content", href: "/saved", icon: "🔖" },
  { name: "Help & Support", href: "/help", icon: "❓" },
]

const adminNavigation = [
  { name: "Admin Dashboard", href: "/admin", icon: "📊" },
  { name: "User Management", href: "/admin/users", icon: "🛡️" },
  { name: "Content Moderation", href: "/admin/moderation", icon: "⚙️" },
]

interface SidebarProps {
  isAdmin?: boolean
}

export function Sidebar({ isAdmin = false }: SidebarProps) {
  const pathname = usePathname()

  return (
    <div className="flex flex-col w-64 bg-sidebar border-r border-sidebar-border">
      <div className="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
        <div className="flex items-center flex-shrink-0 px-4">
          <div className="w-8 h-8 bg-sidebar-primary rounded-full flex items-center justify-center">
            <span className="text-sidebar-primary-foreground font-bold text-sm">Y</span>
          </div>
          <span className="ml-2 text-lg font-semibold text-sidebar-foreground">YMCA</span>
        </div>

        <nav className="mt-8 flex-1 px-2 space-y-1">
          {navigation.map((item) => {
            const isActive = pathname === item.href
            return (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  "group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors",
                  isActive
                    ? "bg-sidebar-accent text-sidebar-accent-foreground"
                    : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                )}
              >
                <span
                  className={cn(
                    "mr-3 flex-shrink-0 h-5 w-5 flex items-center justify-center",
                    isActive ? "text-sidebar-accent-foreground" : "text-sidebar-foreground",
                  )}
                >
                  {item.icon}
                </span>
                {item.name}
                {item.badge && <Badge className="ml-auto bg-accent text-accent-foreground">{item.badge}</Badge>}
              </Link>
            )
          })}
        </nav>

        {/* Quick Links */}
        <div className="mt-8 px-2">
          <h3 className="px-2 text-xs font-semibold text-sidebar-foreground uppercase tracking-wider">Quick Links</h3>
          <nav className="mt-2 space-y-1">
            {quickLinks.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-colors"
              >
                <span className="mr-3 flex-shrink-0 h-4 w-4 flex items-center justify-center">{item.icon}</span>
                {item.name}
              </Link>
            ))}
          </nav>
        </div>

        {/* Admin Section */}
        {isAdmin && (
          <div className="mt-8 px-2">
            <h3 className="px-2 text-xs font-semibold text-sidebar-foreground uppercase tracking-wider">
              Administration
            </h3>
            <nav className="mt-2 space-y-1">
              {adminNavigation.map((item) => {
                const isActive = pathname === item.href
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={cn(
                      "group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors",
                      isActive
                        ? "bg-sidebar-accent text-sidebar-accent-foreground"
                        : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                    )}
                  >
                    <span className="mr-3 flex-shrink-0 h-4 w-4 flex items-center justify-center">{item.icon}</span>
                    {item.name}
                  </Link>
                )
              })}
            </nav>
          </div>
        )}
      </div>
    </div>
  )
}
