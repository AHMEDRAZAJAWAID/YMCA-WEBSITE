"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Bell, MessageSquare, Calendar, Users, Settings, Check, X } from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"

const notifications = [
  {
    id: 1,
    type: "message",
    title: "New message from Sarah Johnson",
    content: "Thanks for organizing the wellness workshop!",
    time: "2 minutes ago",
    read: false,
    avatar: "/placeholder.svg?height=32&width=32",
  },
  {
    id: 2,
    type: "event",
    title: "Upcoming Event: Community Fitness Challenge",
    content: "Don't forget to join us tomorrow at 9 AM",
    time: "1 hour ago",
    read: false,
    avatar: "/placeholder.svg?height=32&width=32",
  },
  {
    id: 3,
    type: "forum",
    title: "New reply in Wellness Discussion",
    content: "Mike Chen replied to your post about nutrition tips",
    time: "3 hours ago",
    read: true,
    avatar: "/placeholder.svg?height=32&width=32",
  },
  {
    id: 4,
    type: "system",
    title: "Profile Update Required",
    content: "Please update your emergency contact information",
    time: "1 day ago",
    read: false,
    avatar: "/placeholder.svg?height=32&width=32",
  },
]

const getNotificationIcon = (type: string) => {
  switch (type) {
    case "message":
      return <MessageSquare className="h-4 w-4" />
    case "event":
      return <Calendar className="h-4 w-4" />
    case "forum":
      return <Users className="h-4 w-4" />
    default:
      return <Bell className="h-4 w-4" />
  }
}

const getNotificationColor = (type: string) => {
  switch (type) {
    case "message":
      return "bg-blue-100 text-blue-800"
    case "event":
      return "bg-green-100 text-green-800"
    case "forum":
      return "bg-purple-100 text-purple-800"
    default:
      return "bg-amber-100 text-amber-800"
  }
}

export default function NotificationsPage() {
  const [notificationList, setNotificationList] = useState(notifications)
  const [settings, setSettings] = useState({
    emailNotifications: true,
    pushNotifications: true,
    messageNotifications: true,
    eventReminders: true,
    forumUpdates: false,
    weeklyDigest: true,
  })

  const markAsRead = (id: number) => {
    setNotificationList((prev) => prev.map((notif) => (notif.id === id ? { ...notif, read: true } : notif)))
  }

  const markAllAsRead = () => {
    setNotificationList((prev) => prev.map((notif) => ({ ...notif, read: true })))
  }

  const deleteNotification = (id: number) => {
    setNotificationList((prev) => prev.filter((notif) => notif.id !== id))
  }

  const unreadCount = notificationList.filter((n) => !n.read).length

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50">
      <div className="container mx-auto p-6">
        <div className="mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-amber-900 mb-2">Notifications</h1>
              <p className="text-amber-700">Stay updated with your YMCA community</p>
            </div>
            {unreadCount > 0 && (
              <Button
                onClick={markAllAsRead}
                variant="outline"
                className="border-amber-300 text-amber-700 hover:bg-amber-100 bg-transparent"
              >
                Mark all as read ({unreadCount})
              </Button>
            )}
          </div>
        </div>

        <Tabs defaultValue="all" className="space-y-6">
          <TabsList className="bg-amber-100">
            <TabsTrigger value="all" className="data-[state=active]:bg-amber-600 data-[state=active]:text-white">
              All Notifications
              {unreadCount > 0 && <Badge className="ml-2 bg-amber-600 text-white">{unreadCount}</Badge>}
            </TabsTrigger>
            <TabsTrigger value="unread" className="data-[state=active]:bg-amber-600 data-[state=active]:text-white">
              Unread
            </TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-amber-600 data-[state=active]:text-white">
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            <Card className="border-amber-200">
              <CardHeader>
                <CardTitle className="text-amber-900">All Notifications</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[600px]">
                  {notificationList.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 border-b border-amber-100 hover:bg-amber-50 transition-colors ${
                        !notification.read ? "bg-amber-25" : ""
                      }`}
                    >
                      <div className="flex items-start space-x-3">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={notification.avatar || "/placeholder.svg"} />
                          <AvatarFallback className="bg-amber-200 text-amber-800">
                            {getNotificationIcon(notification.type)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <h4 className={`font-medium ${!notification.read ? "text-amber-900" : "text-amber-700"}`}>
                              {notification.title}
                            </h4>
                            <div className="flex items-center space-x-2">
                              <Badge variant="secondary" className={getNotificationColor(notification.type)}>
                                {notification.type}
                              </Badge>
                              {!notification.read && <div className="w-2 h-2 bg-amber-600 rounded-full"></div>}
                            </div>
                          </div>
                          <p className="text-sm text-amber-600 mt-1">{notification.content}</p>
                          <div className="flex items-center justify-between mt-2">
                            <span className="text-xs text-amber-500">{notification.time}</span>
                            <div className="flex items-center space-x-2">
                              {!notification.read && (
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => markAsRead(notification.id)}
                                  className="text-amber-600 hover:text-amber-700"
                                >
                                  <Check className="h-3 w-3" />
                                </Button>
                              )}
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => deleteNotification(notification.id)}
                                className="text-red-600 hover:text-red-700"
                              >
                                <X className="h-3 w-3" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="unread" className="space-y-4">
            <Card className="border-amber-200">
              <CardHeader>
                <CardTitle className="text-amber-900">Unread Notifications</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[600px]">
                  {notificationList
                    .filter((n) => !n.read)
                    .map((notification) => (
                      <div
                        key={notification.id}
                        className="p-4 border-b border-amber-100 hover:bg-amber-50 transition-colors bg-amber-25"
                      >
                        <div className="flex items-start space-x-3">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={notification.avatar || "/placeholder.svg"} />
                            <AvatarFallback className="bg-amber-200 text-amber-800">
                              {getNotificationIcon(notification.type)}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <h4 className="font-medium text-amber-900">{notification.title}</h4>
                              <Badge variant="secondary" className={getNotificationColor(notification.type)}>
                                {notification.type}
                              </Badge>
                            </div>
                            <p className="text-sm text-amber-600 mt-1">{notification.content}</p>
                            <div className="flex items-center justify-between mt-2">
                              <span className="text-xs text-amber-500">{notification.time}</span>
                              <Button
                                size="sm"
                                onClick={() => markAsRead(notification.id)}
                                className="bg-amber-600 hover:bg-amber-700"
                              >
                                Mark as read
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-4">
            <Card className="border-amber-200">
              <CardHeader>
                <CardTitle className="text-amber-900 flex items-center">
                  <Settings className="h-5 w-5 mr-2" />
                  Notification Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-amber-900">Email Notifications</h4>
                      <p className="text-sm text-amber-600">Receive notifications via email</p>
                    </div>
                    <Switch
                      checked={settings.emailNotifications}
                      onCheckedChange={(checked) => setSettings((prev) => ({ ...prev, emailNotifications: checked }))}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-amber-900">Push Notifications</h4>
                      <p className="text-sm text-amber-600">Receive browser push notifications</p>
                    </div>
                    <Switch
                      checked={settings.pushNotifications}
                      onCheckedChange={(checked) => setSettings((prev) => ({ ...prev, pushNotifications: checked }))}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-amber-900">Message Notifications</h4>
                      <p className="text-sm text-amber-600">Get notified of new messages</p>
                    </div>
                    <Switch
                      checked={settings.messageNotifications}
                      onCheckedChange={(checked) => setSettings((prev) => ({ ...prev, messageNotifications: checked }))}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-amber-900">Event Reminders</h4>
                      <p className="text-sm text-amber-600">Reminders for upcoming events</p>
                    </div>
                    <Switch
                      checked={settings.eventReminders}
                      onCheckedChange={(checked) => setSettings((prev) => ({ ...prev, eventReminders: checked }))}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-amber-900">Forum Updates</h4>
                      <p className="text-sm text-amber-600">Notifications for forum activity</p>
                    </div>
                    <Switch
                      checked={settings.forumUpdates}
                      onCheckedChange={(checked) => setSettings((prev) => ({ ...prev, forumUpdates: checked }))}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-amber-900">Weekly Digest</h4>
                      <p className="text-sm text-amber-600">Weekly summary of community activity</p>
                    </div>
                    <Switch
                      checked={settings.weeklyDigest}
                      onCheckedChange={(checked) => setSettings((prev) => ({ ...prev, weeklyDigest: checked }))}
                    />
                  </div>
                </div>
                <Button className="bg-amber-600 hover:bg-amber-700">Save Settings</Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
