"use client"

import { useState } from "react"
import { Navbar } from "@/components/layout/navbar"
import { Sidebar } from "@/components/layout/sidebar"
import { Footer } from "@/components/layout/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  User,
  Mail,
  Phone,
  MapPin,
  Globe,
  Linkedin,
  Camera,
  Plus,
  X,
  Save,
  Shield,
  Bell,
  CheckCircle,
} from "lucide-react"

export default function ProfilePage() {
  const [isEditing, setIsEditing] = useState(false)
  const [profileData, setProfileData] = useState({
    firstName: "John",
    lastName: "Doe",
    title: "Program Director",
    organization: "Downtown YMCA",
    email: "john.doe@ymca.org",
    phone: "(555) 123-4567",
    location: "Chicago, IL",
    bio: "Passionate about empowering young people through innovative programs and community engagement. With over 10 years of experience in youth development, I'm committed to creating positive change in our community.",
    website: "johndoe.com",
    linkedin: "linkedin.com/in/johndoe",
    skills: ["Youth Development", "Program Management", "Community Outreach", "Leadership", "Event Planning"],
    interests: ["Leadership", "Health & Wellness", "Education", "Community Service"],
    sig: "Youth Programs",
  })

  const [privacySettings, setPrivacySettings] = useState({
    profileVisible: true,
    emailVisible: false,
    phoneVisible: false,
    showActivity: true,
    allowMessages: true,
    showConnections: true,
  })

  const [notifications, setNotifications] = useState({
    emailNotifications: true,
    pushNotifications: true,
    forumMentions: true,
    eventReminders: true,
    newConnections: true,
    weeklyDigest: false,
  })

  const [newSkill, setNewSkill] = useState("")
  const [newInterest, setNewInterest] = useState("")
  const [saveStatus, setSaveStatus] = useState<"idle" | "saving" | "saved">("idle")

  const handleSave = async () => {
    setSaveStatus("saving")
    // Simulate API call
    setTimeout(() => {
      setSaveStatus("saved")
      setIsEditing(false)
      setTimeout(() => setSaveStatus("idle"), 2000)
    }, 1000)
  }

  const addSkill = () => {
    if (newSkill.trim() && !profileData.skills.includes(newSkill.trim())) {
      setProfileData((prev) => ({
        ...prev,
        skills: [...prev.skills, newSkill.trim()],
      }))
      setNewSkill("")
    }
  }

  const removeSkill = (skill: string) => {
    setProfileData((prev) => ({
      ...prev,
      skills: prev.skills.filter((s) => s !== skill),
    }))
  }

  const addInterest = () => {
    if (newInterest.trim() && !profileData.interests.includes(newInterest.trim())) {
      setProfileData((prev) => ({
        ...prev,
        interests: [...prev.interests, newInterest.trim()],
      }))
      setNewInterest("")
    }
  }

  const removeInterest = (interest: string) => {
    setProfileData((prev) => ({
      ...prev,
      interests: prev.interests.filter((i) => i !== interest),
    }))
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex flex-1">
        <Sidebar />
        <main className="flex-1 p-6 bg-background">
          <div className="max-w-4xl mx-auto space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-foreground mb-2">My Profile</h1>
                <p className="text-muted-foreground">Manage your profile information and privacy settings</p>
              </div>
              <div className="flex items-center space-x-2">
                {saveStatus === "saved" && (
                  <Alert className="w-auto p-2 border-green-200 bg-green-50">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <AlertDescription className="text-green-800 ml-2">Profile saved successfully!</AlertDescription>
                  </Alert>
                )}
                {isEditing ? (
                  <div className="flex space-x-2">
                    <Button variant="outline" onClick={() => setIsEditing(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleSave} disabled={saveStatus === "saving"}>
                      <Save className="h-4 w-4 mr-2" />
                      {saveStatus === "saving" ? "Saving..." : "Save Changes"}
                    </Button>
                  </div>
                ) : (
                  <Button onClick={() => setIsEditing(true)}>
                    <User className="h-4 w-4 mr-2" />
                    Edit Profile
                  </Button>
                )}
              </div>
            </div>

            <Tabs defaultValue="profile" className="space-y-6">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="profile">Profile Information</TabsTrigger>
                <TabsTrigger value="privacy">Privacy Settings</TabsTrigger>
                <TabsTrigger value="notifications">Notifications</TabsTrigger>
              </TabsList>

              <TabsContent value="profile" className="space-y-6">
                {/* Profile Picture & Basic Info */}
                <Card>
                  <CardHeader>
                    <CardTitle>Profile Picture & Basic Information</CardTitle>
                    <CardDescription>This information will be visible to other community members</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex items-center space-x-6">
                      <div className="relative">
                        <Avatar className="h-24 w-24">
                          <AvatarImage src="/professional-headshot.png" alt="Profile" />
                          <AvatarFallback className="text-lg">
                            {profileData.firstName[0]}
                            {profileData.lastName[0]}
                          </AvatarFallback>
                        </Avatar>
                        {isEditing && (
                          <Button
                            size="sm"
                            className="absolute -bottom-2 -right-2 h-8 w-8 rounded-full p-0"
                            variant="secondary"
                          >
                            <Camera className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold text-foreground">
                          {profileData.firstName} {profileData.lastName}
                        </h3>
                        <p className="text-muted-foreground">{profileData.title}</p>
                        <p className="text-sm text-muted-foreground">{profileData.organization}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="firstName">First Name</Label>
                        <Input
                          id="firstName"
                          value={profileData.firstName}
                          onChange={(e) => setProfileData((prev) => ({ ...prev, firstName: e.target.value }))}
                          disabled={!isEditing}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lastName">Last Name</Label>
                        <Input
                          id="lastName"
                          value={profileData.lastName}
                          onChange={(e) => setProfileData((prev) => ({ ...prev, lastName: e.target.value }))}
                          disabled={!isEditing}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="title">Job Title</Label>
                        <Input
                          id="title"
                          value={profileData.title}
                          onChange={(e) => setProfileData((prev) => ({ ...prev, title: e.target.value }))}
                          disabled={!isEditing}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="organization">Organization</Label>
                        <Input
                          id="organization"
                          value={profileData.organization}
                          onChange={(e) => setProfileData((prev) => ({ ...prev, organization: e.target.value }))}
                          disabled={!isEditing}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="bio">Bio</Label>
                      <Textarea
                        id="bio"
                        value={profileData.bio}
                        onChange={(e) => setProfileData((prev) => ({ ...prev, bio: e.target.value }))}
                        disabled={!isEditing}
                        rows={4}
                        placeholder="Tell us about yourself, your experience, and what you're passionate about..."
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Contact Information */}
                <Card>
                  <CardHeader>
                    <CardTitle>Contact Information</CardTitle>
                    <CardDescription>How other members can reach you</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="email">Email Address</Label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                          <Input
                            id="email"
                            type="email"
                            value={profileData.email}
                            onChange={(e) => setProfileData((prev) => ({ ...prev, email: e.target.value }))}
                            disabled={!isEditing}
                            className="pl-10"
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number</Label>
                        <div className="relative">
                          <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                          <Input
                            id="phone"
                            value={profileData.phone}
                            onChange={(e) => setProfileData((prev) => ({ ...prev, phone: e.target.value }))}
                            disabled={!isEditing}
                            className="pl-10"
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="location">Location</Label>
                        <div className="relative">
                          <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                          <Input
                            id="location"
                            value={profileData.location}
                            onChange={(e) => setProfileData((prev) => ({ ...prev, location: e.target.value }))}
                            disabled={!isEditing}
                            className="pl-10"
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="website">Website</Label>
                        <div className="relative">
                          <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                          <Input
                            id="website"
                            value={profileData.website}
                            onChange={(e) => setProfileData((prev) => ({ ...prev, website: e.target.value }))}
                            disabled={!isEditing}
                            className="pl-10"
                            placeholder="https://yourwebsite.com"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="linkedin">LinkedIn Profile</Label>
                      <div className="relative">
                        <Linkedin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                        <Input
                          id="linkedin"
                          value={profileData.linkedin}
                          onChange={(e) => setProfileData((prev) => ({ ...prev, linkedin: e.target.value }))}
                          disabled={!isEditing}
                          className="pl-10"
                          placeholder="linkedin.com/in/yourprofile"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Skills & Interests */}
                <Card>
                  <CardHeader>
                    <CardTitle>Skills & Interests</CardTitle>
                    <CardDescription>Help others find you based on your expertise and interests</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-3">
                      <Label>Skills</Label>
                      <div className="flex flex-wrap gap-2">
                        {profileData.skills.map((skill) => (
                          <Badge key={skill} variant="secondary" className="flex items-center gap-1">
                            {skill}
                            {isEditing && (
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-4 w-4 p-0 hover:bg-transparent"
                                onClick={() => removeSkill(skill)}
                              >
                                <X className="h-3 w-3" />
                              </Button>
                            )}
                          </Badge>
                        ))}
                      </div>
                      {isEditing && (
                        <div className="flex gap-2">
                          <Input
                            placeholder="Add a skill"
                            value={newSkill}
                            onChange={(e) => setNewSkill(e.target.value)}
                            onKeyPress={(e) => e.key === "Enter" && addSkill()}
                          />
                          <Button onClick={addSkill} size="sm">
                            <Plus className="h-4 w-4" />
                          </Button>
                        </div>
                      )}
                    </div>

                    <div className="space-y-3">
                      <Label>Interests</Label>
                      <div className="flex flex-wrap gap-2">
                        {profileData.interests.map((interest) => (
                          <Badge key={interest} variant="outline" className="flex items-center gap-1">
                            {interest}
                            {isEditing && (
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-4 w-4 p-0 hover:bg-transparent"
                                onClick={() => removeInterest(interest)}
                              >
                                <X className="h-3 w-3" />
                              </Button>
                            )}
                          </Badge>
                        ))}
                      </div>
                      {isEditing && (
                        <div className="flex gap-2">
                          <Input
                            placeholder="Add an interest"
                            value={newInterest}
                            onChange={(e) => setNewInterest(e.target.value)}
                            onKeyPress={(e) => e.key === "Enter" && addInterest()}
                          />
                          <Button onClick={addInterest} size="sm">
                            <Plus className="h-4 w-4" />
                          </Button>
                        </div>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="sig">Special Interest Group (SIG)</Label>
                      <Select
                        value={profileData.sig}
                        onValueChange={(value) => setProfileData((prev) => ({ ...prev, sig: value }))}
                        disabled={!isEditing}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Youth Programs">Youth Programs</SelectItem>
                          <SelectItem value="Health & Wellness">Health & Wellness</SelectItem>
                          <SelectItem value="Community Engagement">Community Engagement</SelectItem>
                          <SelectItem value="Leadership">Leadership</SelectItem>
                          <SelectItem value="Aquatics">Aquatics</SelectItem>
                          <SelectItem value="Senior Services">Senior Services</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="privacy" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Shield className="h-5 w-5 mr-2" />
                      Privacy Settings
                    </CardTitle>
                    <CardDescription>Control who can see your information and how you appear to others</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Profile Visibility</Label>
                          <p className="text-sm text-muted-foreground">Make your profile visible to other members</p>
                        </div>
                        <Switch
                          checked={privacySettings.profileVisible}
                          onCheckedChange={(checked) =>
                            setPrivacySettings((prev) => ({ ...prev, profileVisible: checked }))
                          }
                        />
                      </div>

                      <Separator />

                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Show Email Address</Label>
                          <p className="text-sm text-muted-foreground">Allow others to see your email address</p>
                        </div>
                        <Switch
                          checked={privacySettings.emailVisible}
                          onCheckedChange={(checked) =>
                            setPrivacySettings((prev) => ({ ...prev, emailVisible: checked }))
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Show Phone Number</Label>
                          <p className="text-sm text-muted-foreground">Allow others to see your phone number</p>
                        </div>
                        <Switch
                          checked={privacySettings.phoneVisible}
                          onCheckedChange={(checked) =>
                            setPrivacySettings((prev) => ({ ...prev, phoneVisible: checked }))
                          }
                        />
                      </div>

                      <Separator />

                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Show Activity</Label>
                          <p className="text-sm text-muted-foreground">Display your forum posts and event attendance</p>
                        </div>
                        <Switch
                          checked={privacySettings.showActivity}
                          onCheckedChange={(checked) =>
                            setPrivacySettings((prev) => ({ ...prev, showActivity: checked }))
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Allow Messages</Label>
                          <p className="text-sm text-muted-foreground">Let other members send you direct messages</p>
                        </div>
                        <Switch
                          checked={privacySettings.allowMessages}
                          onCheckedChange={(checked) =>
                            setPrivacySettings((prev) => ({ ...prev, allowMessages: checked }))
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Show Connections</Label>
                          <p className="text-sm text-muted-foreground">Display your connection count and network</p>
                        </div>
                        <Switch
                          checked={privacySettings.showConnections}
                          onCheckedChange={(checked) =>
                            setPrivacySettings((prev) => ({ ...prev, showConnections: checked }))
                          }
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="notifications" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Bell className="h-5 w-5 mr-2" />
                      Notification Preferences
                    </CardTitle>
                    <CardDescription>
                      Choose how and when you want to be notified about community activity
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Email Notifications</Label>
                          <p className="text-sm text-muted-foreground">Receive notifications via email</p>
                        </div>
                        <Switch
                          checked={notifications.emailNotifications}
                          onCheckedChange={(checked) =>
                            setNotifications((prev) => ({ ...prev, emailNotifications: checked }))
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Push Notifications</Label>
                          <p className="text-sm text-muted-foreground">Receive browser push notifications</p>
                        </div>
                        <Switch
                          checked={notifications.pushNotifications}
                          onCheckedChange={(checked) =>
                            setNotifications((prev) => ({ ...prev, pushNotifications: checked }))
                          }
                        />
                      </div>

                      <Separator />

                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Forum Mentions</Label>
                          <p className="text-sm text-muted-foreground">When someone mentions you in a forum post</p>
                        </div>
                        <Switch
                          checked={notifications.forumMentions}
                          onCheckedChange={(checked) =>
                            setNotifications((prev) => ({ ...prev, forumMentions: checked }))
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Event Reminders</Label>
                          <p className="text-sm text-muted-foreground">Reminders for events you've registered for</p>
                        </div>
                        <Switch
                          checked={notifications.eventReminders}
                          onCheckedChange={(checked) =>
                            setNotifications((prev) => ({ ...prev, eventReminders: checked }))
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>New Connections</Label>
                          <p className="text-sm text-muted-foreground">When someone wants to connect with you</p>
                        </div>
                        <Switch
                          checked={notifications.newConnections}
                          onCheckedChange={(checked) =>
                            setNotifications((prev) => ({ ...prev, newConnections: checked }))
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Weekly Digest</Label>
                          <p className="text-sm text-muted-foreground">Weekly summary of community activity</p>
                        </div>
                        <Switch
                          checked={notifications.weeklyDigest}
                          onCheckedChange={(checked) =>
                            setNotifications((prev) => ({ ...prev, weeklyDigest: checked }))
                          }
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
      <Footer />
    </div>
  )
}
