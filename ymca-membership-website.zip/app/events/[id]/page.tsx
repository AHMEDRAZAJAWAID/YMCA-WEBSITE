"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Navbar } from "@/components/layout/navbar"
import { Sidebar } from "@/components/layout/sidebar"
import { Footer } from "@/components/layout/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  ArrowLeft,
  Calendar,
  Clock,
  MapPin,
  Users,
  Video,
  ExternalLink,
  Share2,
  Star,
  CheckCircle,
  AlertCircle,
  Mail,
  Phone,
} from "lucide-react"

// Mock event data
const eventData = {
  id: 1,
  title: "Leadership Workshop: Building Effective Teams",
  description: `Join us for an intensive workshop focused on developing essential leadership skills for managing diverse teams and driving community impact. This interactive session will cover key leadership principles, team dynamics, and practical strategies for effective communication and collaboration.

**What You'll Learn:**
• Fundamental leadership principles and styles
• Techniques for building trust and rapport with team members
• Strategies for managing conflict and difficult conversations
• Methods for motivating and inspiring team performance
• Tools for effective delegation and accountability
• Creating inclusive and supportive team environments

**Who Should Attend:**
This workshop is ideal for current and aspiring leaders in YMCA programs, including program directors, coordinators, volunteers, and anyone interested in developing their leadership capabilities.

**Materials Provided:**
All participants will receive a comprehensive leadership toolkit including templates, checklists, and resources for ongoing development.`,
  date: "2024-01-15",
  time: "2:00 PM - 4:00 PM",
  location: "Virtual Event",
  type: "Workshop",
  category: "Leadership",
  organizer: {
    name: "Sarah Johnson",
    title: "Program Director",
    avatar: "/professional-headshot.png",
    email: "sarah.johnson@ymca.org",
    phone: "(555) 123-4567",
    bio: "Sarah has over 10 years of experience in youth development and program management, with a passion for developing the next generation of community leaders.",
  },
  maxAttendees: 50,
  currentAttendees: 32,
  isVirtual: true,
  isFeatured: true,
  registrationDeadline: "2024-01-14",
  status: "upcoming",
  tags: ["Leadership", "Team Building", "Professional Development"],
  meetingLink: "https://zoom.us/j/123456789",
  meetingId: "123 456 789",
  meetingPassword: "YMCA2024",
  agenda: [
    { time: "2:00 PM", item: "Welcome & Introductions" },
    { time: "2:15 PM", item: "Leadership Fundamentals" },
    { time: "2:45 PM", item: "Team Building Strategies" },
    { time: "3:15 PM", item: "Break" },
    { time: "3:30 PM", item: "Communication & Conflict Resolution" },
    { time: "4:00 PM", item: "Q&A & Wrap-up" },
  ],
  prerequisites: ["Basic understanding of team dynamics", "Willingness to participate in group activities"],
  materials: ["Notebook and pen", "Stable internet connection", "Quiet environment for participation"],
  certificate: true,
  ceu: 2,
}

const attendees = [
  { name: "Michael Chen", avatar: null, title: "Youth Coordinator" },
  { name: "Emily Rodriguez", avatar: null, title: "Community Volunteer" },
  { name: "David Thompson", avatar: null, title: "Sports Coach" },
  { name: "Lisa Wang", avatar: null, title: "Board Member" },
  { name: "James Miller", avatar: null, title: "Aquatics Director" },
]

export default function EventDetailPage({ params }: { params: { id: string } }) {
  const [isRegistered, setIsRegistered] = useState(false)
  const [showAttendees, setShowAttendees] = useState(false)

  const handleRSVP = () => {
    setIsRegistered(!isRegistered)
  }

  const handleJoinMeeting = () => {
    if (eventData.meetingLink) {
      window.open(eventData.meetingLink, "_blank")
    }
  }

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: eventData.title,
        text: eventData.description,
        url: window.location.href,
      })
    } else {
      navigator.clipboard.writeText(window.location.href)
    }
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex flex-1">
        <Sidebar />
        <main className="flex-1 p-6 bg-background">
          <div className="max-w-4xl mx-auto space-y-6">
            {/* Breadcrumb */}
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Link href="/events" className="hover:text-foreground">
                Events
              </Link>
              <span>/</span>
              <span className="text-foreground">Event Details</span>
            </div>

            {/* Back Button */}
            <Button variant="outline" asChild className="bg-transparent">
              <Link href="/events">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Events
              </Link>
            </Button>

            {/* Event Header */}
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-3">
                      {eventData.isFeatured && <Star className="h-5 w-5 text-yellow-500" />}
                      <Badge variant={eventData.isVirtual ? "secondary" : "outline"} className="text-sm">
                        {eventData.isVirtual ? "Virtual Event" : "In-Person"}
                      </Badge>
                      <Badge variant="outline" className="text-sm">
                        {eventData.type}
                      </Badge>
                      <Badge className="bg-blue-100 text-blue-800 text-sm">{eventData.category}</Badge>
                    </div>
                    <CardTitle className="text-3xl mb-3">{eventData.title}</CardTitle>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div className="flex items-center text-muted-foreground">
                        <Calendar className="h-4 w-4 mr-2" />
                        <span>
                          {new Date(eventData.date).toLocaleDateString("en-US", {
                            weekday: "long",
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                          })}
                        </span>
                      </div>
                      <div className="flex items-center text-muted-foreground">
                        <Clock className="h-4 w-4 mr-2" />
                        <span>{eventData.time}</span>
                      </div>
                      <div className="flex items-start text-muted-foreground">
                        {eventData.isVirtual ? (
                          <Video className="h-4 w-4 mr-2 mt-0.5" />
                        ) : (
                          <MapPin className="h-4 w-4 mr-2 mt-0.5" />
                        )}
                        <span>{eventData.location}</span>
                      </div>
                      <div className="flex items-center text-muted-foreground">
                        <Users className="h-4 w-4 mr-2" />
                        <span>
                          {eventData.currentAttendees}/{eventData.maxAttendees} registered
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm" onClick={handleShare}>
                      <Share2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
            </Card>

            {/* Registration Alert */}
            {eventData.status === "upcoming" && (
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Registration closes on {new Date(eventData.registrationDeadline).toLocaleDateString()}
                  {eventData.currentAttendees >= eventData.maxAttendees && " • This event is currently full"}
                </AlertDescription>
              </Alert>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Main Content */}
              <div className="lg:col-span-2 space-y-6">
                {/* Description */}
                <Card>
                  <CardHeader>
                    <CardTitle>About This Event</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="prose prose-sm max-w-none">
                      <div className="whitespace-pre-wrap text-foreground">{eventData.description}</div>
                    </div>
                    <div className="flex flex-wrap gap-2 mt-4">
                      {eventData.tags.map((tag) => (
                        <Badge key={tag} variant="secondary">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Agenda */}
                <Card>
                  <CardHeader>
                    <CardTitle>Agenda</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {eventData.agenda.map((item, index) => (
                        <div key={index} className="flex items-start space-x-3">
                          <div className="w-16 text-sm font-medium text-muted-foreground">{item.time}</div>
                          <div className="flex-1 text-sm">{item.item}</div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Prerequisites & Materials */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Prerequisites</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {eventData.prerequisites.map((item, index) => (
                          <li key={index} className="flex items-start space-x-2 text-sm">
                            <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">What to Bring</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {eventData.materials.map((item, index) => (
                          <li key={index} className="flex items-start space-x-2 text-sm">
                            <CheckCircle className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </div>

                {/* Virtual Meeting Details */}
                {eventData.isVirtual && eventData.meetingLink && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <Video className="h-5 w-5 mr-2" />
                        Virtual Meeting Details
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label className="text-sm font-medium">Meeting ID</Label>
                          <p className="text-sm text-muted-foreground">{eventData.meetingId}</p>
                        </div>
                        <div>
                          <Label className="text-sm font-medium">Password</Label>
                          <p className="text-sm text-muted-foreground">{eventData.meetingPassword}</p>
                        </div>
                      </div>
                      <Button onClick={handleJoinMeeting} className="w-full md:w-auto">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Join Meeting
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </div>

              {/* Sidebar */}
              <div className="space-y-6">
                {/* Registration Card */}
                <Card>
                  <CardHeader>
                    <CardTitle>Registration</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-foreground">
                        {eventData.currentAttendees}/{eventData.maxAttendees}
                      </div>
                      <div className="text-sm text-muted-foreground">Registered</div>
                      <div className="w-full bg-muted rounded-full h-2 mt-2">
                        <div
                          className="bg-primary h-2 rounded-full"
                          style={{
                            width: `${(eventData.currentAttendees / eventData.maxAttendees) * 100}%`,
                          }}
                        ></div>
                      </div>
                    </div>

                    {eventData.status === "upcoming" && (
                      <Button
                        onClick={handleRSVP}
                        className="w-full"
                        disabled={eventData.currentAttendees >= eventData.maxAttendees && !isRegistered}
                        variant={isRegistered ? "outline" : "default"}
                      >
                        {isRegistered
                          ? "Cancel Registration"
                          : eventData.currentAttendees >= eventData.maxAttendees
                            ? "Event Full"
                            : "RSVP Now"}
                      </Button>
                    )}

                    {isRegistered && (
                      <Alert>
                        <CheckCircle className="h-4 w-4" />
                        <AlertDescription>You're registered for this event!</AlertDescription>
                      </Alert>
                    )}

                    <div className="text-xs text-muted-foreground text-center">
                      Registration closes: {new Date(eventData.registrationDeadline).toLocaleDateString()}
                    </div>
                  </CardContent>
                </Card>

                {/* Organizer Info */}
                <Card>
                  <CardHeader>
                    <CardTitle>Event Organizer</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={eventData.organizer.avatar || undefined} alt={eventData.organizer.name} />
                        <AvatarFallback>
                          {eventData.organizer.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h4 className="font-semibold text-foreground">{eventData.organizer.name}</h4>
                        <p className="text-sm text-muted-foreground">{eventData.organizer.title}</p>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground">{eventData.organizer.bio}</p>
                    <div className="space-y-2">
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Mail className="h-4 w-4 mr-2" />
                        <a href={`mailto:${eventData.organizer.email}`} className="hover:text-foreground">
                          {eventData.organizer.email}
                        </a>
                      </div>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Phone className="h-4 w-4 mr-2" />
                        <a href={`tel:${eventData.organizer.phone}`} className="hover:text-foreground">
                          {eventData.organizer.phone}
                        </a>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Event Benefits */}
                <Card>
                  <CardHeader>
                    <CardTitle>Event Benefits</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {eventData.certificate && (
                      <div className="flex items-center space-x-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span>Certificate of completion</span>
                      </div>
                    )}
                    {eventData.ceu && (
                      <div className="flex items-center space-x-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span>{eventData.ceu} CEU credits</span>
                      </div>
                    )}
                    <div className="flex items-center space-x-2 text-sm">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span>Networking opportunities</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span>Resource materials included</span>
                    </div>
                  </CardContent>
                </Card>

                {/* Attendees */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>Attendees</span>
                      <Button variant="ghost" size="sm" onClick={() => setShowAttendees(!showAttendees)}>
                        {showAttendees ? "Hide" : "Show All"}
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {(showAttendees ? attendees : attendees.slice(0, 3)).map((attendee, index) => (
                        <div key={index} className="flex items-center space-x-3">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={attendee.avatar || undefined} alt={attendee.name} />
                            <AvatarFallback className="text-xs">
                              {attendee.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="text-sm font-medium">{attendee.name}</p>
                            <p className="text-xs text-muted-foreground">{attendee.title}</p>
                          </div>
                        </div>
                      ))}
                      {!showAttendees && attendees.length > 3 && (
                        <p className="text-xs text-muted-foreground">+{attendees.length - 3} more attendees</p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </main>
      </div>
      <Footer />
    </div>
  )
}

function Label({ children, className }: { children: React.ReactNode; className?: string }) {
  return <label className={`text-sm font-medium ${className}`}>{children}</label>
}
