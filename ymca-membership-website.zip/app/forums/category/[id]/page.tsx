"use client"

import { useState } from "react"
import Link from "next/link"
import { Navbar } from "@/components/layout/navbar"
import { Sidebar } from "@/components/layout/sidebar"
import { Footer } from "@/components/layout/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Search, Plus, Pin, TrendingUp, MessageCircle, Eye, ThumbsUp } from "lucide-react"

// Mock category data
const categoryData = {
  id: 1,
  name: "Youth Programs",
  description: "Discussions about youth development, programs, and activities",
  icon: "👥",
  threads: 45,
  posts: 234,
  moderators: ["Sarah Johnson", "Michael Chen"],
}

const categoryThreads = [
  {
    id: 1,
    title: "Best practices for youth mentorship programs",
    author: "Sarah Johnson",
    avatar: "/professional-headshot.png",
    replies: 12,
    views: 156,
    likes: 8,
    lastReply: "2 hours ago",
    lastReplyBy: "David Thompson",
    createdAt: "2 days ago",
    isPinned: true,
    isHot: true,
  },
  {
    id: 2,
    title: "Summer camp activity ideas and planning",
    author: "Emily Rodriguez",
    avatar: null,
    replies: 8,
    views: 89,
    likes: 15,
    lastReply: "4 hours ago",
    lastReplyBy: "Lisa Wang",
    createdAt: "3 days ago",
    isPinned: false,
    isHot: true,
  },
  {
    id: 3,
    title: "Youth leadership development strategies",
    author: "Michael Chen",
    avatar: null,
    replies: 15,
    views: 203,
    likes: 12,
    lastReply: "6 hours ago",
    lastReplyBy: "Robert Thompson",
    createdAt: "5 days ago",
    isPinned: false,
    isHot: true,
  },
  {
    id: 4,
    title: "Engaging teenagers in community service",
    author: "David Thompson",
    avatar: null,
    replies: 6,
    views: 67,
    likes: 4,
    lastReply: "1 day ago",
    lastReplyBy: "Sarah Johnson",
    createdAt: "1 week ago",
    isPinned: false,
    isHot: false,
  },
  {
    id: 5,
    title: "After-school program curriculum ideas",
    author: "Lisa Wang",
    avatar: null,
    replies: 9,
    views: 124,
    likes: 7,
    lastReply: "2 days ago",
    lastReplyBy: "Emily Rodriguez",
    createdAt: "1 week ago",
    isPinned: false,
    isHot: false,
  },
]

export default function CategoryPage({ params }: { params: { id: string } }) {
  const [searchTerm, setSearchTerm] = useState("")
  const [sortBy, setSortBy] = useState("recent")

  const filteredThreads = categoryThreads.filter(
    (thread) =>
      thread.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      thread.author.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex flex-1">
        <Sidebar />
        <main className="flex-1 p-6 bg-background">
          <div className="max-w-6xl mx-auto space-y-6">
            {/* Breadcrumb */}
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Link href="/forums" className="hover:text-foreground">
                Forums
              </Link>
              <span>/</span>
              <span className="text-foreground">{categoryData.name}</span>
            </div>

            {/* Back Button */}
            <Button variant="outline" asChild className="bg-transparent">
              <Link href="/forums">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Forums
              </Link>
            </Button>

            {/* Category Header */}
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4">
                    <div className="text-4xl">{categoryData.icon}</div>
                    <div>
                      <CardTitle className="text-2xl mb-2">{categoryData.name}</CardTitle>
                      <CardDescription className="text-base mb-4">{categoryData.description}</CardDescription>
                      <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                        <div className="flex items-center">
                          <MessageCircle className="h-4 w-4 mr-1" />
                          <span>{categoryData.threads} threads</span>
                        </div>
                        <div className="flex items-center">
                          <span>{categoryData.posts} posts</span>
                        </div>
                        <div>
                          <span>Moderators: {categoryData.moderators.join(", ")}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    New Thread
                  </Button>
                </div>
              </CardHeader>
            </Card>

            {/* Search and Sort */}
            <Card>
              <CardContent className="p-4">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                      <Input
                        placeholder="Search threads in this category..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="w-full md:w-48">
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="recent">Most Recent</SelectItem>
                      <SelectItem value="popular">Most Popular</SelectItem>
                      <SelectItem value="replies">Most Replies</SelectItem>
                      <SelectItem value="views">Most Views</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Threads List */}
            <Card>
              <CardHeader>
                <CardTitle>Discussions ({filteredThreads.length})</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {filteredThreads.map((thread) => (
                  <Link key={thread.id} href={`/forums/thread/${thread.id}`}>
                    <Card className="hover:shadow-md transition-shadow cursor-pointer">
                      <CardContent className="p-4">
                        <div className="flex items-start space-x-4">
                          <Avatar className="h-10 w-10">
                            <AvatarImage src={thread.avatar || undefined} alt={thread.author} />
                            <AvatarFallback>
                              {thread.author
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between mb-2">
                              <div className="flex items-center space-x-2">
                                {thread.isPinned && <Pin className="h-4 w-4 text-accent" />}
                                {thread.isHot && <TrendingUp className="h-4 w-4 text-orange-500" />}
                                <h3 className="font-semibold text-foreground line-clamp-1">{thread.title}</h3>
                              </div>
                            </div>
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                                <span>by {thread.author}</span>
                                <span>{thread.createdAt}</span>
                              </div>
                              <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                                <div className="flex items-center">
                                  <MessageCircle className="h-3 w-3 mr-1" />
                                  <span>{thread.replies}</span>
                                </div>
                                <div className="flex items-center">
                                  <Eye className="h-3 w-3 mr-1" />
                                  <span>{thread.views}</span>
                                </div>
                                <div className="flex items-center">
                                  <ThumbsUp className="h-3 w-3 mr-1" />
                                  <span>{thread.likes}</span>
                                </div>
                              </div>
                            </div>
                            <div className="mt-2 text-xs text-muted-foreground">
                              Last reply by {thread.lastReplyBy} • {thread.lastReply}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </CardContent>
            </Card>

            {/* No Threads Found Message */}
            {filteredThreads.length === 0 && (
              <Card>
                <CardContent className="text-center py-12">
                  <MessageCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-foreground mb-2">No threads found</h3>
                  <p className="text-muted-foreground mb-4">
                    {searchTerm ? "Try adjusting your search terms." : "Be the first to start a discussion!"}
                  </p>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Start New Thread
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </main>
      </div>
      <Footer />
    </div>
  )
}
