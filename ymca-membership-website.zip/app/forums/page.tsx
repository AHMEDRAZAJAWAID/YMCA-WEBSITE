"use client"

import { useState } from "react"
import Link from "next/link"
import { Navbar } from "@/components/layout/navbar"
import { Sidebar } from "@/components/layout/sidebar"
import { Footer } from "@/components/layout/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Search,
  MessageSquare,
  Users,
  Clock,
  TrendingUp,
  Pin,
  Plus,
  Eye,
  ThumbsUp,
  MessageCircle,
  Filter,
} from "lucide-react"

// Mock data for forum categories and threads
const forumCategories = [
  {
    id: 1,
    name: "Youth Programs",
    description: "Discussions about youth development, programs, and activities",
    color: "bg-blue-100 text-blue-800",
    icon: "👥",
    threads: 45,
    posts: 234,
    lastActivity: "2 hours ago",
    lastPost: {
      title: "Summer Camp Planning Ideas",
      author: "Sarah Johnson",
      time: "2 hours ago",
    },
  },
  {
    id: 2,
    name: "Health & Wellness",
    description: "Share wellness tips, fitness programs, and health initiatives",
    color: "bg-green-100 text-green-800",
    icon: "💪",
    threads: 32,
    posts: 189,
    lastActivity: "4 hours ago",
    lastPost: {
      title: "Mental Health Resources for Staff",
      author: "Dr. Michael Chen",
      time: "4 hours ago",
    },
  },
  {
    id: 3,
    name: "Community Engagement",
    description: "Building stronger communities through outreach and partnerships",
    color: "bg-purple-100 text-purple-800",
    icon: "🤝",
    threads: 28,
    posts: 156,
    lastActivity: "6 hours ago",
    lastPost: {
      title: "Volunteer Appreciation Event Ideas",
      author: "Emily Rodriguez",
      time: "6 hours ago",
    },
  },
  {
    id: 4,
    name: "Leadership Development",
    description: "Leadership skills, management strategies, and professional growth",
    color: "bg-orange-100 text-orange-800",
    icon: "🎯",
    threads: 21,
    posts: 98,
    lastActivity: "1 day ago",
    lastPost: {
      title: "Effective Team Communication Strategies",
      author: "Robert Thompson",
      time: "1 day ago",
    },
  },
  {
    id: 5,
    name: "Aquatics & Safety",
    description: "Water safety, swim programs, and aquatic facility management",
    color: "bg-cyan-100 text-cyan-800",
    icon: "🏊",
    threads: 18,
    posts: 87,
    lastActivity: "2 days ago",
    lastPost: {
      title: "New Pool Safety Protocols",
      author: "James Miller",
      time: "2 days ago",
    },
  },
  {
    id: 6,
    name: "Technology & Innovation",
    description: "Digital tools, software solutions, and tech innovations for YMCAs",
    color: "bg-indigo-100 text-indigo-800",
    icon: "💻",
    threads: 15,
    posts: 72,
    lastActivity: "3 days ago",
    lastPost: {
      title: "Member Management Software Comparison",
      author: "Lisa Wang",
      time: "3 days ago",
    },
  },
]

const recentThreads = [
  {
    id: 1,
    title: "Best practices for youth mentorship programs",
    category: "Youth Programs",
    author: "Sarah Johnson",
    avatar: "/professional-headshot.png",
    replies: 12,
    views: 156,
    likes: 8,
    lastReply: "2 hours ago",
    isPinned: true,
    isHot: true,
  },
  {
    id: 2,
    title: "Mental health resources and support strategies",
    category: "Health & Wellness",
    author: "Dr. Michael Chen",
    avatar: null,
    replies: 8,
    views: 89,
    likes: 15,
    lastReply: "4 hours ago",
    isPinned: false,
    isHot: true,
  },
  {
    id: 3,
    title: "Community partnership success stories",
    category: "Community Engagement",
    author: "Emily Rodriguez",
    avatar: null,
    replies: 6,
    views: 67,
    likes: 4,
    lastReply: "6 hours ago",
    isPinned: false,
    isHot: false,
  },
  {
    id: 4,
    title: "Leadership training workshop feedback",
    category: "Leadership Development",
    author: "Robert Thompson",
    avatar: null,
    replies: 15,
    views: 203,
    likes: 12,
    lastReply: "1 day ago",
    isPinned: false,
    isHot: true,
  },
  {
    id: 5,
    title: "Pool maintenance and safety checklist",
    category: "Aquatics & Safety",
    author: "James Miller",
    avatar: null,
    replies: 4,
    views: 45,
    likes: 2,
    lastReply: "2 days ago",
    isPinned: false,
    isHot: false,
  },
]

export default function ForumsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [sortBy, setSortBy] = useState("recent")
  const [filterCategory, setFilterCategory] = useState("all")

  const filteredThreads = recentThreads.filter((thread) => {
    const matchesSearch =
      thread.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      thread.author.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = filterCategory === "all" || thread.category === filterCategory
    return matchesSearch && matchesCategory
  })

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex flex-1">
        <Sidebar />
        <main className="flex-1 p-6 bg-background">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-foreground mb-2">Discussion Forums</h1>
                <p className="text-muted-foreground">
                  Connect with the community, share knowledge, and engage in meaningful discussions
                </p>
              </div>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                New Discussion
              </Button>
            </div>

            {/* Search and Filters */}
            <Card>
              <CardContent className="p-4">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                      <Input
                        placeholder="Search discussions..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <Select value={filterCategory} onValueChange={setFilterCategory}>
                    <SelectTrigger className="w-full md:w-48">
                      <Filter className="h-4 w-4 mr-2" />
                      <SelectValue placeholder="All Categories" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      {forumCategories.map((category) => (
                        <SelectItem key={category.id} value={category.name}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="w-full md:w-48">
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="recent">Most Recent</SelectItem>
                      <SelectItem value="popular">Most Popular</SelectItem>
                      <SelectItem value="replies">Most Replies</SelectItem>
                      <SelectItem value="views">Most Views</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Forum Categories */}
              <div className="lg:col-span-2 space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <MessageSquare className="h-5 w-5 mr-2" />
                      Forum Categories
                    </CardTitle>
                    <CardDescription>Browse discussions by topic</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {forumCategories.map((category) => (
                      <Link key={category.id} href={`/forums/category/${category.id}`}>
                        <Card className="hover:shadow-md transition-shadow cursor-pointer">
                          <CardContent className="p-4">
                            <div className="flex items-start space-x-4">
                              <div className="text-2xl">{category.icon}</div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center justify-between mb-2">
                                  <h3 className="font-semibold text-foreground">{category.name}</h3>
                                  <Badge className={category.color}>{category.threads} threads</Badge>
                                </div>
                                <p className="text-sm text-muted-foreground mb-3">{category.description}</p>
                                <div className="flex items-center justify-between text-xs text-muted-foreground">
                                  <div className="flex items-center space-x-4">
                                    <span>{category.posts} posts</span>
                                    <span>Last activity: {category.lastActivity}</span>
                                  </div>
                                  <div className="text-right">
                                    <p className="font-medium text-foreground">{category.lastPost.title}</p>
                                    <p>by {category.lastPost.author}</p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </Link>
                    ))}
                  </CardContent>
                </Card>

                {/* Recent Discussions */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <TrendingUp className="h-5 w-5 mr-2" />
                      Recent Discussions
                    </CardTitle>
                    <CardDescription>Latest activity across all categories</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {filteredThreads.map((thread) => (
                      <Link key={thread.id} href={`/forums/thread/${thread.id}`}>
                        <Card className="hover:shadow-md transition-shadow cursor-pointer">
                          <CardContent className="p-4">
                            <div className="flex items-start space-x-3">
                              <Avatar className="h-10 w-10">
                                <AvatarImage src={thread.avatar || undefined} alt={thread.author} />
                                <AvatarFallback>
                                  {thread.author
                                    .split(" ")
                                    .map((n) => n[0])
                                    .join("")}
                                </AvatarFallback>
                              </Avatar>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-start justify-between mb-2">
                                  <div className="flex items-center space-x-2">
                                    {thread.isPinned && <Pin className="h-4 w-4 text-accent" />}
                                    {thread.isHot && <TrendingUp className="h-4 w-4 text-orange-500" />}
                                    <h3 className="font-semibold text-foreground line-clamp-1">{thread.title}</h3>
                                  </div>
                                  <Badge variant="secondary" className="text-xs">
                                    {thread.category}
                                  </Badge>
                                </div>
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                                    <span>by {thread.author}</span>
                                    <div className="flex items-center">
                                      <MessageCircle className="h-3 w-3 mr-1" />
                                      <span>{thread.replies}</span>
                                    </div>
                                    <div className="flex items-center">
                                      <Eye className="h-3 w-3 mr-1" />
                                      <span>{thread.views}</span>
                                    </div>
                                    <div className="flex items-center">
                                      <ThumbsUp className="h-3 w-3 mr-1" />
                                      <span>{thread.likes}</span>
                                    </div>
                                  </div>
                                  <div className="flex items-center text-xs text-muted-foreground">
                                    <Clock className="h-3 w-3 mr-1" />
                                    <span>Last reply {thread.lastReply}</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </Link>
                    ))}
                  </CardContent>
                </Card>
              </div>

              {/* Sidebar */}
              <div className="space-y-6">
                {/* Forum Stats */}
                <Card>
                  <CardHeader>
                    <CardTitle>Forum Statistics</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Total Threads</span>
                      <span className="font-semibold">159</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Total Posts</span>
                      <span className="font-semibold">836</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Active Members</span>
                      <span className="font-semibold">234</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Online Now</span>
                      <span className="font-semibold text-green-600">18</span>
                    </div>
                  </CardContent>
                </Card>

                {/* Top Contributors */}
                <Card>
                  <CardHeader>
                    <CardTitle>Top Contributors</CardTitle>
                    <CardDescription>Most active members this month</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {[
                      { name: "Sarah Johnson", posts: 23, avatar: "/professional-headshot.png" },
                      { name: "Michael Chen", posts: 18, avatar: null },
                      { name: "Emily Rodriguez", posts: 15, avatar: null },
                      { name: "Robert Thompson", posts: 12, avatar: null },
                    ].map((contributor, index) => (
                      <div key={contributor.name} className="flex items-center space-x-3">
                        <div className="flex items-center justify-center w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-bold">
                          {index + 1}
                        </div>
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={contributor.avatar || undefined} alt={contributor.name} />
                          <AvatarFallback className="text-xs">
                            {contributor.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <p className="text-sm font-medium">{contributor.name}</p>
                          <p className="text-xs text-muted-foreground">{contributor.posts} posts</p>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                {/* Quick Actions */}
                <Card>
                  <CardHeader>
                    <CardTitle>Quick Actions</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Button variant="outline" className="w-full justify-start bg-transparent">
                      <Plus className="h-4 w-4 mr-2" />
                      Start New Discussion
                    </Button>
                    <Button variant="outline" className="w-full justify-start bg-transparent">
                      <Users className="h-4 w-4 mr-2" />
                      Browse Members
                    </Button>
                    <Button variant="outline" className="w-full justify-start bg-transparent">
                      <Search className="h-4 w-4 mr-2" />
                      Advanced Search
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </main>
      </div>
      <Footer />
    </div>
  )
}
