"use client"

import { useState } from "react"
import Link from "next/link"
import { Navbar } from "@/components/layout/navbar"
import { Sidebar } from "@/components/layout/sidebar"
import { Footer } from "@/components/layout/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  ArrowLeft,
  ThumbsUp,
  ThumbsDown,
  MessageCircle,
  Share2,
  Flag,
  Clock,
  Eye,
  Pin,
  TrendingUp,
  Send,
  Quote,
} from "lucide-react"

// Mock thread data
const threadData = {
  id: 1,
  title: "Best practices for youth mentorship programs",
  category: "Youth Programs",
  author: "Sarah Johnson",
  authorAvatar: "/professional-headshot.png",
  authorTitle: "Program Director",
  authorPosts: 156,
  authorJoined: "Jan 2022",
  createdAt: "2 days ago",
  views: 234,
  replies: 12,
  likes: 18,
  isPinned: true,
  isHot: true,
  content: `I wanted to start a discussion about effective mentorship programs for youth. After running several programs over the past few years, I've learned some valuable lessons that I'd love to share and get feedback on.

**Key Elements I've Found Essential:**

1. **Structured Training for Mentors** - We provide 8 hours of initial training covering child development, communication skills, and program expectations.

2. **Clear Goals and Expectations** - Both mentors and mentees understand what they're working toward from day one.

3. **Regular Check-ins** - Monthly group meetings and quarterly one-on-ones help maintain momentum.

4. **Activity-Based Interactions** - Rather than just talking, we incorporate hands-on activities that naturally build relationships.

**Challenges We've Faced:**
- Mentor retention (especially during busy seasons)
- Matching personalities effectively
- Measuring long-term impact

What strategies have worked best in your programs? I'm particularly interested in hearing about innovative approaches to mentor training and retention.`,
}

const replies = [
  {
    id: 1,
    author: "Michael Chen",
    authorAvatar: null,
    authorTitle: "Youth Coordinator",
    authorPosts: 89,
    authorJoined: "Mar 2022",
    createdAt: "1 day ago",
    content: `Great post, Sarah! We've had similar experiences with mentor retention. One thing that's worked well for us is creating a mentor buddy system where experienced mentors are paired with new ones. This provides additional support and helps with retention.

We also started doing quarterly appreciation events specifically for mentors - nothing fancy, just pizza and recognition. It's made a noticeable difference in engagement.`,
    likes: 8,
    dislikes: 0,
    isLiked: false,
    isDisliked: false,
  },
  {
    id: 2,
    author: "Emily Rodriguez",
    authorAvatar: null,
    authorTitle: "Community Volunteer",
    authorPosts: 203,
    authorJoined: "Sep 2021",
    createdAt: "1 day ago",
    content: `The activity-based approach is so important! We've found that service projects work particularly well - mentors and mentees working together on community service creates natural bonding opportunities while teaching valuable lessons about giving back.

Some of our most successful matches have come from shared interests discovered during these activities.`,
    likes: 12,
    dislikes: 1,
    isLiked: true,
    isDisliked: false,
  },
  {
    id: 3,
    author: "David Thompson",
    authorAvatar: null,
    authorTitle: "Youth Sports Coach",
    authorPosts: 124,
    authorJoined: "Jun 2022",
    createdAt: "18 hours ago",
    content: `@Sarah Johnson - Have you experimented with group mentoring? We've had success with small groups (3-4 youth with 2 mentors) for certain activities. It takes pressure off individual mentors and creates peer support among the youth.

The sports angle has been huge for us too. Many of our most engaged mentors are former athletes who connect through shared sports experiences.`,
    likes: 6,
    dislikes: 0,
    isLiked: false,
    isDisliked: false,
  },
]

export default function ThreadPage({ params }: { params: { id: string } }) {
  const [newReply, setNewReply] = useState("")
  const [isLiked, setIsLiked] = useState(false)
  const [isDisliked, setIsDisliked] = useState(false)
  const [replyLikes, setReplyLikes] = useState<{ [key: number]: { liked: boolean; disliked: boolean } }>({})

  const handleLike = () => {
    setIsLiked(!isLiked)
    if (isDisliked) setIsDisliked(false)
  }

  const handleDislike = () => {
    setIsDisliked(!isDisliked)
    if (isLiked) setIsLiked(false)
  }

  const handleReplyLike = (replyId: number, type: "like" | "dislike") => {
    setReplyLikes((prev) => ({
      ...prev,
      [replyId]: {
        liked: type === "like" ? !prev[replyId]?.liked : false,
        disliked: type === "dislike" ? !prev[replyId]?.disliked : false,
      },
    }))
  }

  const handleSubmitReply = () => {
    if (newReply.trim()) {
      // Handle reply submission
      console.log("Submitting reply:", newReply)
      setNewReply("")
    }
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex flex-1">
        <Sidebar />
        <main className="flex-1 p-6 bg-background">
          <div className="max-w-4xl mx-auto space-y-6">
            {/* Breadcrumb */}
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Link href="/forums" className="hover:text-foreground">
                Forums
              </Link>
              <span>/</span>
              <Link href={`/forums/category/1`} className="hover:text-foreground">
                {threadData.category}
              </Link>
              <span>/</span>
              <span className="text-foreground">Discussion</span>
            </div>

            {/* Back Button */}
            <Button variant="outline" asChild className="bg-transparent">
              <Link href="/forums">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Forums
              </Link>
            </Button>

            {/* Thread Header */}
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      {threadData.isPinned && <Pin className="h-4 w-4 text-accent" />}
                      {threadData.isHot && <TrendingUp className="h-4 w-4 text-orange-500" />}
                      <Badge className="bg-blue-100 text-blue-800">{threadData.category}</Badge>
                    </div>
                    <CardTitle className="text-2xl mb-2">{threadData.title}</CardTitle>
                    <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                      <div className="flex items-center">
                        <Eye className="h-4 w-4 mr-1" />
                        <span>{threadData.views} views</span>
                      </div>
                      <div className="flex items-center">
                        <MessageCircle className="h-4 w-4 mr-1" />
                        <span>{threadData.replies} replies</span>
                      </div>
                      <div className="flex items-center">
                        <ThumbsUp className="h-4 w-4 mr-1" />
                        <span>{threadData.likes} likes</span>
                      </div>
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 mr-1" />
                        <span>{threadData.createdAt}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm">
                      <Share2 className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm">
                      <Flag className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
            </Card>

            {/* Original Post */}
            <Card>
              <CardContent className="p-6">
                <div className="flex space-x-4">
                  <div className="flex flex-col items-center space-y-2">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={threadData.authorAvatar || "/placeholder.svg"} alt={threadData.author} />
                      <AvatarFallback>
                        {threadData.author
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div className="text-center">
                      <p className="text-sm font-medium">{threadData.author}</p>
                      <p className="text-xs text-muted-foreground">{threadData.authorTitle}</p>
                      <p className="text-xs text-muted-foreground">{threadData.authorPosts} posts</p>
                      <p className="text-xs text-muted-foreground">Joined {threadData.authorJoined}</p>
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="prose prose-sm max-w-none">
                      <div className="whitespace-pre-wrap text-foreground">{threadData.content}</div>
                    </div>
                    <div className="flex items-center justify-between mt-6 pt-4 border-t border-border">
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={handleLike}
                          className={isLiked ? "text-green-600" : ""}
                        >
                          <ThumbsUp className="h-4 w-4 mr-1" />
                          {threadData.likes + (isLiked ? 1 : 0)}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={handleDislike}
                          className={isDisliked ? "text-red-600" : ""}
                        >
                          <ThumbsDown className="h-4 w-4 mr-1" />
                          {isDisliked ? 1 : 0}
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Quote className="h-4 w-4 mr-1" />
                          Quote
                        </Button>
                      </div>
                      <div className="text-xs text-muted-foreground">Posted {threadData.createdAt}</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Replies */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-foreground">
                {replies.length} {replies.length === 1 ? "Reply" : "Replies"}
              </h3>

              {replies.map((reply) => (
                <Card key={reply.id}>
                  <CardContent className="p-6">
                    <div className="flex space-x-4">
                      <div className="flex flex-col items-center space-y-2">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={reply.authorAvatar || undefined} alt={reply.author} />
                          <AvatarFallback>
                            {reply.author
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="text-center">
                          <p className="text-sm font-medium">{reply.author}</p>
                          <p className="text-xs text-muted-foreground">{reply.authorTitle}</p>
                          <p className="text-xs text-muted-foreground">{reply.authorPosts} posts</p>
                        </div>
                      </div>
                      <div className="flex-1">
                        <div className="prose prose-sm max-w-none">
                          <div className="whitespace-pre-wrap text-foreground">{reply.content}</div>
                        </div>
                        <div className="flex items-center justify-between mt-4 pt-3 border-t border-border">
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleReplyLike(reply.id, "like")}
                              className={replyLikes[reply.id]?.liked ? "text-green-600" : ""}
                            >
                              <ThumbsUp className="h-4 w-4 mr-1" />
                              {reply.likes + (replyLikes[reply.id]?.liked ? 1 : 0)}
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleReplyLike(reply.id, "dislike")}
                              className={replyLikes[reply.id]?.disliked ? "text-red-600" : ""}
                            >
                              <ThumbsDown className="h-4 w-4 mr-1" />
                              {reply.dislikes + (replyLikes[reply.id]?.disliked ? 1 : 0)}
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Quote className="h-4 w-4 mr-1" />
                              Quote
                            </Button>
                          </div>
                          <div className="text-xs text-muted-foreground">Posted {reply.createdAt}</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Reply Form */}
            <Card>
              <CardHeader>
                <CardTitle>Post a Reply</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  placeholder="Share your thoughts and contribute to the discussion..."
                  value={newReply}
                  onChange={(e) => setNewReply(e.target.value)}
                  rows={6}
                />
                <div className="flex justify-between items-center">
                  <p className="text-sm text-muted-foreground">Be respectful and constructive in your responses</p>
                  <Button onClick={handleSubmitReply} disabled={!newReply.trim()}>
                    <Send className="h-4 w-4 mr-2" />
                    Post Reply
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
      <Footer />
    </div>
  )
}
