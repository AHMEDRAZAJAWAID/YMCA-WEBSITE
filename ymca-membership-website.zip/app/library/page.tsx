"use client"

import { useState } from "react"
import { Navbar } from "@/components/layout/navbar"
import { Sidebar } from "@/components/layout/sidebar"
import { Footer } from "@/components/layout/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Search,
  Upload,
  FileText,
  Video,
  LinkIcon,
  Download,
  Eye,
  Heart,
  Share2,
  Grid3X3,
  List,
  Star,
} from "lucide-react"

// Mock content library data
const libraryContent = [
  {
    id: 1,
    title: "Youth Program Development Guide",
    description:
      "Comprehensive guide for developing effective youth programs including planning, implementation, and evaluation strategies.",
    type: "document",
    category: "Youth Programs",
    author: "Sarah Johnson",
    authorAvatar: "/professional-headshot.png",
    uploadDate: "2024-01-10",
    fileSize: "2.4 MB",
    downloads: 156,
    views: 342,
    likes: 28,
    tags: ["Youth Development", "Program Planning", "Best Practices"],
    isFeatured: true,
    fileUrl: "/documents/youth-program-guide.pdf",
  },
  {
    id: 2,
    title: "Community Health Workshop Recording",
    description:
      "Recording of our recent community health workshop covering mental health awareness and wellness strategies.",
    type: "video",
    category: "Health & Wellness",
    author: "Dr. Michael Chen",
    authorAvatar: null,
    uploadDate: "2024-01-08",
    fileSize: "245 MB",
    downloads: 89,
    views: 234,
    likes: 45,
    tags: ["Mental Health", "Wellness", "Workshop"],
    isFeatured: true,
    fileUrl: "/videos/health-workshop.mp4",
    duration: "1h 32m",
  },
  {
    id: 3,
    title: "Leadership Assessment Tools",
    description: "Collection of assessment tools and templates for evaluating leadership skills and development needs.",
    type: "document",
    category: "Leadership",
    author: "Robert Thompson",
    authorAvatar: null,
    uploadDate: "2024-01-05",
    fileSize: "1.8 MB",
    downloads: 203,
    views: 456,
    likes: 67,
    tags: ["Leadership", "Assessment", "Templates"],
    isFeatured: false,
    fileUrl: "/documents/leadership-assessment.pdf",
  },
  {
    id: 4,
    title: "Volunteer Management Best Practices",
    description:
      "External resource from the National Council of Nonprofits on effective volunteer management strategies.",
    type: "link",
    category: "Community Engagement",
    author: "Emily Rodriguez",
    authorAvatar: null,
    uploadDate: "2024-01-03",
    fileSize: null,
    downloads: 0,
    views: 178,
    likes: 23,
    tags: ["Volunteers", "Management", "External Resource"],
    isFeatured: false,
    fileUrl: "https://www.councilofnonprofits.org/volunteer-management",
  },
  {
    id: 5,
    title: "Aquatic Safety Training Materials",
    description:
      "Complete training materials for aquatic safety certification including videos, handouts, and assessment forms.",
    type: "document",
    category: "Aquatics",
    author: "James Miller",
    authorAvatar: null,
    uploadDate: "2023-12-28",
    fileSize: "5.2 MB",
    downloads: 124,
    views: 289,
    likes: 34,
    tags: ["Aquatics", "Safety", "Training", "Certification"],
    isFeatured: false,
    fileUrl: "/documents/aquatic-safety.pdf",
  },
  {
    id: 6,
    title: "Digital Marketing Webinar Series",
    description: "Three-part webinar series on digital marketing strategies for nonprofit organizations.",
    type: "video",
    category: "Professional Development",
    author: "Lisa Wang",
    authorAvatar: null,
    uploadDate: "2023-12-20",
    fileSize: "680 MB",
    downloads: 67,
    views: 145,
    likes: 19,
    tags: ["Marketing", "Digital", "Webinar Series"],
    isFeatured: false,
    fileUrl: "/videos/marketing-webinar.mp4",
    duration: "3h 15m",
  },
]

export default function LibraryPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [typeFilter, setTypeFilter] = useState("all")
  const [sortBy, setSortBy] = useState("recent")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [activeTab, setActiveTab] = useState("all")

  const filteredContent = libraryContent.filter((item) => {
    const matchesSearch =
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase()))

    const matchesCategory = categoryFilter === "all" || item.category === categoryFilter
    const matchesType = typeFilter === "all" || item.type === typeFilter
    const matchesTab = activeTab === "all" || (activeTab === "featured" && item.isFeatured)

    return matchesSearch && matchesCategory && matchesType && matchesTab
  })

  const getFileIcon = (type: string) => {
    switch (type) {
      case "document":
        return <FileText className="h-8 w-8 text-blue-600" />
      case "video":
        return <Video className="h-8 w-8 text-red-600" />
      case "link":
        return <LinkIcon className="h-8 w-8 text-green-600" />
      default:
        return <FileText className="h-8 w-8 text-gray-600" />
    }
  }

  const ContentCard = ({ item }: { item: (typeof libraryContent)[0] }) => (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex items-start space-x-3">
            <div className="flex-shrink-0">{getFileIcon(item.type)}</div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center space-x-2 mb-2">
                {item.isFeatured && <Star className="h-4 w-4 text-yellow-500" />}
                <Badge variant="outline" className="text-xs">
                  {item.type}
                </Badge>
                <Badge variant="secondary" className="text-xs">
                  {item.category}
                </Badge>
              </div>
              <CardTitle className="text-lg line-clamp-2">{item.title}</CardTitle>
              <CardDescription className="line-clamp-2 mt-2">{item.description}</CardDescription>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex flex-wrap gap-1">
            {item.tags.map((tag) => (
              <Badge key={tag} variant="secondary" className="text-xs">
                {tag}
              </Badge>
            ))}
          </div>

          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <Avatar className="h-6 w-6">
              <AvatarImage src={item.authorAvatar || undefined} alt={item.author} />
              <AvatarFallback className="text-xs">
                {item.author
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </AvatarFallback>
            </Avatar>
            <span>by {item.author}</span>
            <span>•</span>
            <span>{new Date(item.uploadDate).toLocaleDateString()}</span>
          </div>

          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <div className="flex items-center space-x-4">
              <div className="flex items-center">
                <Eye className="h-4 w-4 mr-1" />
                <span>{item.views}</span>
              </div>
              <div className="flex items-center">
                <Download className="h-4 w-4 mr-1" />
                <span>{item.downloads}</span>
              </div>
              <div className="flex items-center">
                <Heart className="h-4 w-4 mr-1" />
                <span>{item.likes}</span>
              </div>
            </div>
            <div className="flex items-center space-x-1">
              {item.fileSize && <span>{item.fileSize}</span>}
              {item.duration && <span>• {item.duration}</span>}
            </div>
          </div>

          <div className="flex items-center justify-between pt-3 border-t border-border">
            <div className="flex space-x-2">
              <Button size="sm" variant="outline">
                <Eye className="h-3 w-3 mr-1" />
                View
              </Button>
              {item.type !== "link" && (
                <Button size="sm" variant="outline">
                  <Download className="h-3 w-3 mr-1" />
                  Download
                </Button>
              )}
            </div>
            <div className="flex space-x-1">
              <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                <Heart className="h-3 w-3" />
              </Button>
              <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                <Share2 className="h-3 w-3" />
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  const ContentListItem = ({ item }: { item: (typeof libraryContent)[0] }) => (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex items-start space-x-4">
          <div className="flex-shrink-0">{getFileIcon(item.type)}</div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                {item.isFeatured && <Star className="h-4 w-4 text-yellow-500" />}
                <h3 className="font-semibold text-foreground line-clamp-1">{item.title}</h3>
              </div>
              <div className="flex items-center space-x-2">
                <Badge variant="outline" className="text-xs">
                  {item.type}
                </Badge>
                <Badge variant="secondary" className="text-xs">
                  {item.category}
                </Badge>
              </div>
            </div>
            <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{item.description}</p>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                <div className="flex items-center space-x-2">
                  <Avatar className="h-5 w-5">
                    <AvatarImage src={item.authorAvatar || undefined} alt={item.author} />
                    <AvatarFallback className="text-xs">
                      {item.author
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <span>{item.author}</span>
                </div>
                <span>•</span>
                <span>{new Date(item.uploadDate).toLocaleDateString()}</span>
                <div className="flex items-center space-x-3">
                  <div className="flex items-center">
                    <Eye className="h-3 w-3 mr-1" />
                    <span>{item.views}</span>
                  </div>
                  <div className="flex items-center">
                    <Download className="h-3 w-3 mr-1" />
                    <span>{item.downloads}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Button size="sm" variant="outline">
                  <Eye className="h-3 w-3 mr-1" />
                  View
                </Button>
                {item.type !== "link" && (
                  <Button size="sm" variant="outline">
                    <Download className="h-3 w-3 mr-1" />
                    Download
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex flex-1">
        <Sidebar />
        <main className="flex-1 p-6 bg-background">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-foreground mb-2">Content Library</h1>
                <p className="text-muted-foreground">
                  Access documents, videos, and resources shared by the YMCA community
                </p>
              </div>
              <Button>
                <Upload className="h-4 w-4 mr-2" />
                Upload Content
              </Button>
            </div>

            {/* Search and Filters */}
            <Card>
              <CardContent className="p-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                  <div className="lg:col-span-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                      <Input
                        placeholder="Search content..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      <SelectItem value="Youth Programs">Youth Programs</SelectItem>
                      <SelectItem value="Health & Wellness">Health & Wellness</SelectItem>
                      <SelectItem value="Leadership">Leadership</SelectItem>
                      <SelectItem value="Community Engagement">Community Engagement</SelectItem>
                      <SelectItem value="Aquatics">Aquatics</SelectItem>
                      <SelectItem value="Professional Development">Professional Development</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={typeFilter} onValueChange={setTypeFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="document">Documents</SelectItem>
                      <SelectItem value="video">Videos</SelectItem>
                      <SelectItem value="link">Links</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger>
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="recent">Most Recent</SelectItem>
                      <SelectItem value="popular">Most Popular</SelectItem>
                      <SelectItem value="downloads">Most Downloaded</SelectItem>
                      <SelectItem value="likes">Most Liked</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Content Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <div className="flex items-center justify-between">
                <TabsList>
                  <TabsTrigger value="all">All Content</TabsTrigger>
                  <TabsTrigger value="featured">Featured</TabsTrigger>
                </TabsList>
                <div className="flex items-center space-x-2">
                  <Button
                    variant={viewMode === "grid" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setViewMode("grid")}
                  >
                    <Grid3X3 className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewMode === "list" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setViewMode("list")}
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <TabsContent value={activeTab} className="mt-6">
                {/* Results Count */}
                <div className="mb-4">
                  <p className="text-sm text-muted-foreground">Showing {filteredContent.length} items</p>
                </div>

                {/* Content Grid/List */}
                {filteredContent.length > 0 ? (
                  viewMode === "grid" ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {filteredContent.map((item) => (
                        <ContentCard key={item.id} item={item} />
                      ))}
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {filteredContent.map((item) => (
                        <ContentListItem key={item.id} item={item} />
                      ))}
                    </div>
                  )
                ) : (
                  <Card>
                    <CardContent className="text-center py-12">
                      <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-foreground mb-2">No content found</h3>
                      <p className="text-muted-foreground">
                        Try adjusting your search criteria or upload new content to get started.
                      </p>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
      <Footer />
    </div>
  )
}
