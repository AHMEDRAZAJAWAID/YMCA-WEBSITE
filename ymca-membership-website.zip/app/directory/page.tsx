"use client"

import { useState, useEffect } from "react"
import { Navbar } from "@/components/layout/navbar"
import { Sidebar } from "@/components/layout/sidebar"
import { Footer } from "@/components/layout/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, MapPin, Building, Users, MessageSquare, Mail, Star, Grid3X3, List, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Member {
  id: number
  name: string
  title: string
  organization: string
  location: string
  skills: string[]
  interests: string[]
  sig: string
  avatar?: string
  bio: string
  email: string
  phone: string
  linkedin?: string
  website?: string
  rating: number
  connections: number
  posts: number
}

export default function DirectoryPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [locationFilter, setLocationFilter] = useState("all")
  const [skillFilter, setSkillFilter] = useState("all")
  const [sigFilter, setSigFilter] = useState("all")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [members, setMembers] = useState<Member[]>([])
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    const loadMembers = async () => {
      setLoading(true)
      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // In a real app, this would fetch from your API
      // For now, we'll show empty state
      setMembers([])
      setLoading(false)
    }

    loadMembers()
  }, [])

  const filteredMembers = members.filter((member) => {
    const matchesSearch =
      member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      member.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      member.organization.toLowerCase().includes(searchTerm.toLowerCase()) ||
      member.skills.some((skill) => skill.toLowerCase().includes(searchTerm.toLowerCase()))

    const matchesLocation = locationFilter === "all" || member.location.includes(locationFilter)
    const matchesSkill = skillFilter === "all" || member.skills.some((skill) => skill.includes(skillFilter))
    const matchesSig = sigFilter === "all" || member.sig === sigFilter

    return matchesSearch && matchesLocation && matchesSkill && matchesSig
  })

  const handleSendMessage = (member: Member) => {
    toast({
      title: "Message Sent",
      description: `Your message to ${member.name} has been sent successfully.`,
    })
  }

  const handleSendEmail = (member: Member) => {
    window.location.href = `mailto:${member.email}?subject=YMCA Community Connection`
  }

  const MemberCard = ({ member }: { member: Member }) => (
    <Card className="hover:shadow-lg transition-shadow cursor-pointer">
      <CardHeader className="pb-3">
        <div className="flex items-start space-x-3">
          <Avatar className="h-12 w-12">
            <AvatarImage src={member.avatar || undefined} alt={member.name} />
            <AvatarFallback>
              {member.name
                .split(" ")
                .map((n) => n[0])
                .join("")}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-foreground truncate">{member.name}</h3>
            <p className="text-sm text-muted-foreground truncate">{member.title}</p>
            <div className="flex items-center text-xs text-muted-foreground mt-1">
              <Building className="h-3 w-3 mr-1" />
              <span className="truncate">{member.organization}</span>
            </div>
            <div className="flex items-center text-xs text-muted-foreground mt-1">
              <MapPin className="h-3 w-3 mr-1" />
              <span>{member.location}</span>
            </div>
          </div>
          <div className="flex items-center">
            <Star className="h-4 w-4 text-yellow-500 mr-1" />
            <span className="text-sm font-medium">{member.rating}</span>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{member.bio}</p>

        <div className="space-y-2">
          <div>
            <p className="text-xs font-medium text-foreground mb-1">Skills</p>
            <div className="flex flex-wrap gap-1">
              {member.skills.slice(0, 3).map((skill) => (
                <Badge key={skill} variant="secondary" className="text-xs">
                  {skill}
                </Badge>
              ))}
              {member.skills.length > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{member.skills.length - 3}
                </Badge>
              )}
            </div>
          </div>

          <div>
            <p className="text-xs font-medium text-foreground mb-1">SIG</p>
            <Badge className="text-xs">{member.sig}</Badge>
          </div>
        </div>

        <div className="flex items-center justify-between mt-4 pt-3 border-t border-border">
          <div className="flex items-center space-x-4 text-xs text-muted-foreground">
            <div className="flex items-center">
              <Users className="h-3 w-3 mr-1" />
              <span>{member.connections}</span>
            </div>
            <div className="flex items-center">
              <MessageSquare className="h-3 w-3 mr-1" />
              <span>{member.posts}</span>
            </div>
          </div>
          <div className="flex space-x-1">
            <Button
              size="sm"
              variant="outline"
              className="h-8 w-8 p-0 bg-transparent"
              onClick={() => handleSendMessage(member)}
            >
              <MessageSquare className="h-3 w-3" />
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="h-8 w-8 p-0 bg-transparent"
              onClick={() => handleSendEmail(member)}
            >
              <Mail className="h-3 w-3" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  const MemberListItem = ({ member }: { member: Member }) => (
    <Card className="hover:shadow-md transition-shadow cursor-pointer">
      <CardContent className="p-4">
        <div className="flex items-center space-x-4">
          <Avatar className="h-12 w-12">
            <AvatarImage src={member.avatar || undefined} alt={member.name} />
            <AvatarFallback>
              {member.name
                .split(" ")
                .map((n) => n[0])
                .join("")}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-foreground">{member.name}</h3>
                <p className="text-sm text-muted-foreground">{member.title}</p>
              </div>
              <div className="flex items-center">
                <Star className="h-4 w-4 text-yellow-500 mr-1" />
                <span className="text-sm font-medium">{member.rating}</span>
              </div>
            </div>
            <div className="flex items-center space-x-4 mt-2 text-xs text-muted-foreground">
              <div className="flex items-center">
                <Building className="h-3 w-3 mr-1" />
                <span>{member.organization}</span>
              </div>
              <div className="flex items-center">
                <MapPin className="h-3 w-3 mr-1" />
                <span>{member.location}</span>
              </div>
              <Badge variant="secondary" className="text-xs">
                {member.sig}
              </Badge>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-4 text-xs text-muted-foreground mr-4">
              <div className="flex items-center">
                <Users className="h-3 w-3 mr-1" />
                <span>{member.connections}</span>
              </div>
              <div className="flex items-center">
                <MessageSquare className="h-3 w-3 mr-1" />
                <span>{member.posts}</span>
              </div>
            </div>
            <Button
              size="sm"
              variant="outline"
              className="h-8 w-8 p-0 bg-transparent"
              onClick={() => handleSendMessage(member)}
            >
              <MessageSquare className="h-3 w-3" />
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="h-8 w-8 p-0 bg-transparent"
              onClick={() => handleSendEmail(member)}
            >
              <Mail className="h-3 w-3" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex flex-1">
        <Sidebar />
        <main className="flex-1 p-6 bg-background">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Header */}
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">Member Directory</h1>
              <p className="text-muted-foreground">
                Connect with YMCA members across the community. Search by name, skills, location, or interests.
              </p>
            </div>

            {/* Search and Filters */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Search className="h-5 w-5 mr-2" />
                  Search & Filter
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                  <div className="lg:col-span-2">
                    <Input
                      placeholder="Search by name, title, organization, or skills..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full"
                    />
                  </div>
                  <Select value={locationFilter} onValueChange={setLocationFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Location" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Locations</SelectItem>
                      <SelectItem value="Chicago">Chicago, IL</SelectItem>
                      <SelectItem value="Seattle">Seattle, WA</SelectItem>
                      <SelectItem value="Los Angeles">Los Angeles, CA</SelectItem>
                      <SelectItem value="Denver">Denver, CO</SelectItem>
                      <SelectItem value="Austin">Austin, TX</SelectItem>
                      <SelectItem value="Miami">Miami, FL</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={skillFilter} onValueChange={setSkillFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Skills" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Skills</SelectItem>
                      <SelectItem value="Youth Development">Youth Development</SelectItem>
                      <SelectItem value="Program Management">Program Management</SelectItem>
                      <SelectItem value="Fitness Training">Fitness Training</SelectItem>
                      <SelectItem value="Event Planning">Event Planning</SelectItem>
                      <SelectItem value="Sports Coaching">Sports Coaching</SelectItem>
                      <SelectItem value="Strategic Planning">Strategic Planning</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={sigFilter} onValueChange={setSigFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="SIG" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All SIGs</SelectItem>
                      <SelectItem value="Youth Programs">Youth Programs</SelectItem>
                      <SelectItem value="Health & Wellness">Health & Wellness</SelectItem>
                      <SelectItem value="Community Engagement">Community Engagement</SelectItem>
                      <SelectItem value="Leadership">Leadership</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Results Header */}
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">
                  {loading ? "Loading members..." : `Showing ${filteredMembers.length} members`}
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  variant={viewMode === "grid" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setViewMode("grid")}
                >
                  <Grid3X3 className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setViewMode("list")}
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {loading ? (
              <Card>
                <CardContent className="text-center py-12">
                  <Loader2 className="h-12 w-12 text-muted-foreground mx-auto mb-4 animate-spin" />
                  <h3 className="text-lg font-semibold text-foreground mb-2">Loading Members</h3>
                  <p className="text-muted-foreground">Please wait while we fetch the member directory...</p>
                </CardContent>
              </Card>
            ) : members.length === 0 ? (
              <Card>
                <CardContent className="text-center py-12">
                  <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-foreground mb-2">No Members Yet</h3>
                  <p className="text-muted-foreground mb-4">
                    The member directory is currently empty. Members will appear here once they join the community.
                  </p>
                  <Button>Invite Members</Button>
                </CardContent>
              </Card>
            ) : (
              <>
                {/* Members Grid/List */}
                {viewMode === "grid" ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredMembers.map((member) => (
                      <MemberCard key={member.id} member={member} />
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {filteredMembers.map((member) => (
                      <MemberListItem key={member.id} member={member} />
                    ))}
                  </div>
                )}

                {filteredMembers.length === 0 && (
                  <Card>
                    <CardContent className="text-center py-12">
                      <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-foreground mb-2">No members found</h3>
                      <p className="text-muted-foreground">Try adjusting your search criteria or filters.</p>
                    </CardContent>
                  </Card>
                )}
              </>
            )}
          </div>
        </main>
      </div>
      <Footer />
    </div>
  )
}
