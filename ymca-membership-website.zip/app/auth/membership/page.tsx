"use client"

import type React from "react"
import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CreditCard, Upload, Calendar, Award as IdCard, AlertCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function MembershipPage() {
  const [formData, setFormData] = useState({
    membershipCardPic: null as File | null,
    membershipNumber: "",
    dob: "",
    bloodGroup: "",
    cnic: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const { toast } = useToast()

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleCardPicUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setFormData((prev) => ({ ...prev, membershipCardPic: file }))
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    // Validation for all required fields
    if (!formData.membershipCardPic) {
      setError("Membership card picture is required")
      setIsLoading(false)
      return
    }

    if (!formData.membershipNumber.trim()) {
      setError("Membership number is required")
      setIsLoading(false)
      return
    }

    if (!formData.dob) {
      setError("Date of birth is required")
      setIsLoading(false)
      return
    }

    if (!formData.bloodGroup) {
      setError("Blood group is required")
      setIsLoading(false)
      return
    }

    if (!formData.cnic.trim()) {
      setError("CNIC is required")
      setIsLoading(false)
      return
    }

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2000))

      toast({
        title: "Membership Verification Successful!",
        description: "Your membership has been verified successfully.",
      })

      // Redirect to thank you page (F-03)
      window.location.href = "/auth/thank-you"
    } catch (error) {
      setError("Verification failed. Please try again.")
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-amber-50 to-orange-50 p-4">
      <div className="w-full max-w-2xl">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-amber-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-white font-bold text-2xl">Y</span>
          </div>
          <h1 className="text-2xl font-bold text-amber-900">Membership Verification</h1>
          <p className="text-amber-700">Membership Form (F-02)</p>
        </div>

        <Card className="border-amber-200">
          <CardHeader>
            <CardTitle className="text-amber-900">Membership Verification</CardTitle>
            <CardDescription>Please provide your membership details for verification</CardDescription>
          </CardHeader>
          <CardContent>
            {error && (
              <Alert className="mb-4" variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Membership Card Picture */}
              <div className="space-y-2">
                <Label htmlFor="membershipCardPic">M.S Card Pic (Membership Card Picture)</Label>
                <div className="flex items-center space-x-4">
                  <div className="w-32 h-20 bg-amber-100 rounded-lg flex items-center justify-center border-2 border-amber-200">
                    {formData.membershipCardPic ? (
                      <img
                        src={URL.createObjectURL(formData.membershipCardPic) || "/placeholder.svg"}
                        alt="Membership Card"
                        className="w-full h-full rounded-lg object-cover"
                      />
                    ) : (
                      <CreditCard className="h-8 w-8 text-amber-600" />
                    )}
                  </div>
                  <div>
                    <Input
                      id="membershipCardPic"
                      type="file"
                      accept="image/*"
                      onChange={handleCardPicUpload}
                      className="hidden"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => document.getElementById("membershipCardPic")?.click()}
                      className="border-amber-300 text-amber-700 hover:bg-amber-100"
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Upload Card Picture
                    </Button>
                  </div>
                </div>
              </div>

              {/* Membership Number */}
              <div className="space-y-2">
                <Label htmlFor="membershipNumber">M.S Number (Membership Number)</Label>
                <div className="relative">
                  <CreditCard className="absolute left-3 top-1/2 transform -translate-y-1/2 text-amber-600 h-4 w-4" />
                  <Input
                    id="membershipNumber"
                    placeholder="Enter your membership number"
                    value={formData.membershipNumber}
                    onChange={(e) => handleInputChange("membershipNumber", e.target.value)}
                    className="pl-10 border-amber-200 focus:border-amber-400"
                    required
                  />
                </div>
              </div>

              {/* Date of Birth */}
              <div className="space-y-2">
                <Label htmlFor="dob">D.O.B (Date of Birth)</Label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-amber-600 h-4 w-4" />
                  <Input
                    id="dob"
                    type="date"
                    value={formData.dob}
                    onChange={(e) => handleInputChange("dob", e.target.value)}
                    className="pl-10 border-amber-200 focus:border-amber-400"
                    required
                  />
                </div>
              </div>

              {/* Blood Group */}
              <div className="space-y-2">
                <Label htmlFor="bloodGroup">Blood Group</Label>
                <Select onValueChange={(value) => handleInputChange("bloodGroup", value)}>
                  <SelectTrigger className="border-amber-200 focus:border-amber-400">
                    <SelectValue placeholder="Select your blood group" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="A+">A+</SelectItem>
                    <SelectItem value="A-">A-</SelectItem>
                    <SelectItem value="B+">B+</SelectItem>
                    <SelectItem value="B-">B-</SelectItem>
                    <SelectItem value="AB+">AB+</SelectItem>
                    <SelectItem value="AB-">AB-</SelectItem>
                    <SelectItem value="O+">O+</SelectItem>
                    <SelectItem value="O-">O-</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* CNIC */}
              <div className="space-y-2">
                <Label htmlFor="cnic">CNIC</Label>
                <div className="relative">
                  <IdCard className="absolute left-3 top-1/2 transform -translate-y-1/2 text-amber-600 h-4 w-4" />
                  <Input
                    id="cnic"
                    placeholder="Enter your CNIC (e.g., 12345-1234567-1)"
                    value={formData.cnic}
                    onChange={(e) => handleInputChange("cnic", e.target.value)}
                    className="pl-10 border-amber-200 focus:border-amber-400"
                    required
                  />
                </div>
              </div>

              <Button type="submit" className="w-full bg-amber-600 hover:bg-amber-700" disabled={isLoading}>
                {isLoading ? "Verifying..." : "Verify Membership"}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-sm text-muted-foreground">
                Need to go back?{" "}
                <Link href="/auth/register" className="text-amber-600 hover:underline">
                  Return to Registration
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
