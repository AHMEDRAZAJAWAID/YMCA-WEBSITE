"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { CreditCard, Calendar, Droplets, Award as IdCard, CheckCircle, AlertCircle, Upload } from "lucide-react"

export default function VerifyMembershipPage() {
  const [membershipNumber, setMembershipNumber] = useState("")
  const [verificationStatus, setVerificationStatus] = useState<"pending" | "verified" | "failed" | null>(null)
  const [memberData, setMemberData] = useState<any>(null)

  const handleVerification = () => {
    console.log("[v0] Verifying membership:", membershipNumber)

    // Simulate verification process
    setTimeout(() => {
      if (membershipNumber === "12345") {
        setMemberData({
          name: "John Smith",
          membershipNumber: "12345",
          dateOfBirth: "1990-05-15",
          bloodGroup: "O+",
          cnic: "12345-6789012-3",
          profilePic: "/placeholder.svg?height=100&width=100",
          membershipType: "Premium",
          expiryDate: "2025-12-31",
          status: "Active",
        })
        setVerificationStatus("verified")
      } else {
        setVerificationStatus("failed")
      }
    }, 2000)

    setVerificationStatus("pending")
  }

  const handleDocumentUpload = (type: string) => {
    console.log("[v0] Uploading document:", type)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50 p-6">
      <div className="container mx-auto max-w-4xl">
        <div className="mb-6 text-center">
          <h1 className="text-3xl font-bold text-amber-900 mb-2">Membership Verification</h1>
          <p className="text-amber-700">Verify your YMCA membership details</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Verification Form */}
          <Card className="border-amber-200">
            <CardHeader>
              <CardTitle className="text-amber-900 flex items-center">
                <IdCard className="h-5 w-5 mr-2" />
                Membership Verification
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="membership-number" className="text-amber-900">
                  Membership Number
                </Label>
                <Input
                  id="membership-number"
                  placeholder="Enter your membership number"
                  value={membershipNumber}
                  onChange={(e) => setMembershipNumber(e.target.value)}
                  className="border-amber-200 focus:border-amber-400"
                />
              </div>

              <Button
                onClick={handleVerification}
                disabled={!membershipNumber || verificationStatus === "pending"}
                className="w-full bg-amber-600 hover:bg-amber-700"
              >
                {verificationStatus === "pending" ? "Verifying..." : "Verify Membership"}
              </Button>

              {verificationStatus === "pending" && (
                <div className="flex items-center justify-center p-4">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-amber-600"></div>
                </div>
              )}

              {verificationStatus === "failed" && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <div className="flex items-center space-x-2">
                    <AlertCircle className="h-5 w-5 text-red-600" />
                    <p className="text-red-800 font-medium">Verification Failed</p>
                  </div>
                  <p className="text-red-700 text-sm mt-1">
                    Membership number not found. Please check your number or contact support.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Document Upload */}
          <Card className="border-amber-200">
            <CardHeader>
              <CardTitle className="text-amber-900 flex items-center">
                <Upload className="h-5 w-5 mr-2" />
                Document Upload
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="border-2 border-dashed border-amber-300 rounded-lg p-4 text-center hover:border-amber-400 transition-colors cursor-pointer">
                  <CreditCard className="h-8 w-8 text-amber-600 mx-auto mb-2" />
                  <p className="text-amber-900 font-medium">Membership Card</p>
                  <p className="text-amber-600 text-sm">Upload a photo of your membership card</p>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-2 border-amber-300 text-amber-700 hover:bg-amber-100 bg-transparent"
                    onClick={() => handleDocumentUpload("membership-card")}
                  >
                    Choose File
                  </Button>
                </div>

                <div className="border-2 border-dashed border-amber-300 rounded-lg p-4 text-center hover:border-amber-400 transition-colors cursor-pointer">
                  <IdCard className="h-8 w-8 text-amber-600 mx-auto mb-2" />
                  <p className="text-amber-900 font-medium">CNIC/ID Card</p>
                  <p className="text-amber-600 text-sm">Upload a copy of your CNIC or ID card</p>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-2 border-amber-300 text-amber-700 hover:bg-amber-100 bg-transparent"
                    onClick={() => handleDocumentUpload("cnic")}
                  >
                    Choose File
                  </Button>
                </div>
              </div>

              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                <p className="text-amber-800 text-sm">
                  <strong>Note:</strong> All uploaded documents will be securely stored and used only for verification
                  purposes.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Verification Results */}
        {verificationStatus === "verified" && memberData && (
          <Card className="border-amber-200 mt-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-amber-900 flex items-center">
                  <CheckCircle className="h-5 w-5 mr-2 text-green-600" />
                  Membership Verified
                </CardTitle>
                <Badge className="bg-green-100 text-green-800">Verified</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <Avatar className="h-16 w-16">
                      <AvatarImage src={memberData.profilePic || "/placeholder.svg"} />
                      <AvatarFallback className="bg-amber-200 text-amber-800 text-lg">
                        {memberData.name
                          .split(" ")
                          .map((n: string) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="text-xl font-semibold text-amber-900">{memberData.name}</h3>
                      <p className="text-amber-600">Member #{memberData.membershipNumber}</p>
                      <Badge variant="secondary" className="mt-1">
                        {memberData.membershipType}
                      </Badge>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <Label className="text-amber-700 text-sm">Date of Birth</Label>
                      <div className="flex items-center space-x-2">
                        <Calendar className="h-4 w-4 text-amber-600" />
                        <span className="text-amber-900">{memberData.dateOfBirth}</span>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <Label className="text-amber-700 text-sm">Blood Group</Label>
                      <div className="flex items-center space-x-2">
                        <Droplets className="h-4 w-4 text-amber-600" />
                        <span className="text-amber-900">{memberData.bloodGroup}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                    <h4 className="font-medium text-amber-900 mb-2">Membership Details</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-amber-700">Status:</span>
                        <Badge className="bg-green-100 text-green-800">{memberData.status}</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-amber-700">Type:</span>
                        <span className="text-amber-900">{memberData.membershipType}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-amber-700">Expires:</span>
                        <span className="text-amber-900">{memberData.expiryDate}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-amber-700">CNIC:</span>
                        <span className="text-amber-900">{memberData.cnic}</span>
                      </div>
                    </div>
                  </div>

                  <Button className="w-full bg-amber-600 hover:bg-amber-700">Complete Registration</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
