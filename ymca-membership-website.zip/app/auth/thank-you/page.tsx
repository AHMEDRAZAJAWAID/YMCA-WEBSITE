"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle, ArrowRight } from "lucide-react"
import Link from "next/link"

export default function ThankYouPage() {
  const [countdown, setCountdown] = useState(5)

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50 flex items-center justify-center p-6">
      <Card className="w-full max-w-2xl border-amber-200 shadow-lg">
        <CardHeader className="text-center pb-6">
          <div className="mx-auto mb-4 w-20 h-20 bg-amber-600 rounded-full flex items-center justify-center">
            <CheckCircle className="h-10 w-10 text-white" />
          </div>
          <CardTitle className="text-4xl font-bold text-amber-900 mb-4">Thank You!</CardTitle>
          <p className="text-amber-700 text-xl">
            Your registration and membership verification have been completed successfully.
          </p>
        </CardHeader>

        <CardContent className="space-y-6">
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-6 text-center">
            <h3 className="font-semibold text-amber-900 text-lg mb-3">Welcome to YMCA Community!</h3>
            <p className="text-amber-700 mb-4">
              Your account has been created and your membership has been verified. You can now access all community
              features.
            </p>
            <div className="text-amber-600 text-lg font-medium">
              Redirecting to login page in {countdown} seconds...
            </div>
          </div>

          <div className="text-center space-y-4">
            <div className="flex justify-center space-x-4">
              <Link href="/auth/login">
                <Button className="bg-amber-600 hover:bg-amber-700 text-lg px-8 py-3">
                  Continue to Login
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link href="/">
                <Button
                  variant="outline"
                  className="border-amber-300 text-amber-700 hover:bg-amber-100 bg-transparent text-lg px-8 py-3"
                >
                  Back to Home
                </Button>
              </Link>
            </div>
          </div>

          <div className="text-center text-sm text-amber-600 border-t border-amber-200 pt-4">
            <p>
              Need help? Contact us at{" "}
              <a href="mailto:support@ymca.org" className="text-amber-700 hover:underline">
                support@ymca.org
              </a>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
